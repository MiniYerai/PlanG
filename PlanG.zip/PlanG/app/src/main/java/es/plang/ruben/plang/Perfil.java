package es.plang.ruben.plang;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import es.plang.ruben.plang.PeticionBD.JSONUtil;
import es.plang.ruben.plang.PeticionBD.Tags;
import es.plang.ruben.plang.models.Usuario;
import es.plang.ruben.plang.utils.DatePickerFragment;

public class Perfil extends AppCompatActivity {

    Usuario usu;

    public TextView tvN;
    public TextView tvF;
    public TextView tvC;
    public TextView tvL;

    public TextView lN;
    public TextView lF;
    public TextView lC;
    public TextView lL;

    public TextInputLayout tA;
    public TextInputLayout tN;
    public TextInputLayout tC;
    public TextInputLayout tL;

    public AutoCompleteTextView etN;
    public AutoCompleteTextView etA;
    public AutoCompleteTextView etC;
    public AutoCompleteTextView etL;

    public LinearLayout ll1;
    public LinearLayout ll2;
    public LinearLayout ll3;
    public LinearLayout ll4;

    public RelativeLayout rlFecha;
    public TextView tvFecha2;

    public Button btGuardar;
    public Button btEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //elimina la barra existente
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_perfil);

        ll1 = (LinearLayout) findViewById(R.id.ll1);
        ll2 = (LinearLayout) findViewById(R.id.ll2);
        ll3 = (LinearLayout) findViewById(R.id.ll3);
        ll4 = (LinearLayout) findViewById(R.id.ll4);

        tvN = (TextView) findViewById(R.id.tvNombre);
        tvF = (TextView) findViewById(R.id.tvFecha2);
        tvC = (TextView) findViewById(R.id.tvCodigo);
        tvL = (TextView) findViewById(R.id.tvLoca);

        lN = (TextView) findViewById(R.id.lNombre);
        lF = (TextView) findViewById(R.id.lFecha);
        lC = (TextView) findViewById(R.id.lpostal);
        lL = (TextView) findViewById(R.id.lLocalidad);

        tN = (TextInputLayout) findViewById(R.id.tNombre);
        tA = (TextInputLayout) findViewById(R.id.tApe);
        tC = (TextInputLayout) findViewById(R.id.tCodigo);
        tL = (TextInputLayout) findViewById(R.id.tLoca);

        etN = (AutoCompleteTextView) findViewById(R.id.etNombre);
        etA = (AutoCompleteTextView) findViewById(R.id.etApe);
        etC = (AutoCompleteTextView) findViewById(R.id.etCodigo);
        etL = (AutoCompleteTextView) findViewById(R.id.etLoca);

        rlFecha = (RelativeLayout) findViewById(R.id.rlFecha);

        btGuardar = (Button) findViewById(R.id.btGuardar);
        btEdit = (Button) findViewById(R.id.btEditar);

        cargarPerfil();

        if(Usuario.getToken(getApplicationContext()).length()<=0) {
            Intent inicio = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(inicio);
        }

        //barra de loguin
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //boton de atras
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        //boton de atras
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //boton editar perfil
        btEdit = (Button) findViewById(R.id.btEditar);
        btEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editarPerfil();
            }
        });

        etL.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                String nombre = etN.getText().toString();
                String apellidos = etA.getText().toString();
                String codigo = etC.getText().toString();
                String loca = etL.getText().toString();
                String f = tvFecha2.getText().toString();

                guardar(nombre, apellidos, codigo, loca, f);
                return false;
            }

        });
    }

    // muenu del action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.action_logout:
                cerrarSesion();
                Toast.makeText(this, "Se ha cerrado la sesion", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void cargarPerfil(){


        JSONObject respuesta = new JSONObject();
        JSONObject enviar = new JSONObject();

        try {

            //recibe la respuesta del servidor
            enviar.put(Tags.RESULTADO,"OK");
            enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
            enviar.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));
            respuesta = JSONUtil.hacerPeticionServidor("java/prefil/",enviar);

//            Log.i("NULL:","-----------------------------------------");
//            Log.i("NULL:",respuesta.getString(Tags.RESULTADO));
//            Log.i("NULL:",respuesta.toString());
            //comprueba de que se realizo con exito
            if(respuesta.getString(Tags.RESULTADO).contains("ok")){
//                Log.e("RESULTADO", respuesta.toString());
                usu = new Usuario(respuesta);
                mostrarPerfil();
//                Toast.makeText(this, "Perfil", Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {

            e.printStackTrace();
        }
    }

    private void mostrarPerfil(){

        tvN.setText(usu.getNombre()+" "+usu.getApellidos());
        tvF.setText(usu.getFecha_nacimiento2());
        if(usu.getCodigo_postal().length()>0) {
            tvC.setText(usu.getCodigo_postal() + "");
        }
        tvL.setText(usu.getLocalidad());
    }

    private void editarPerfil(){

        ll1.setVisibility(View.GONE);
        ll2.setVisibility(View.GONE);
        ll3.setVisibility(View.GONE);
        ll4.setVisibility(View.GONE);

        lN.setVisibility(View.GONE);
        lF.setVisibility(View.GONE);
        lC.setVisibility(View.GONE);
        lL.setVisibility(View.GONE);

        tN.setVisibility(View.VISIBLE);
        tA.setVisibility(View.VISIBLE);
        tC.setVisibility(View.VISIBLE);
        tL.setVisibility(View.VISIBLE);
        rlFecha.setVisibility(View.VISIBLE);

        tvFecha2 = (TextView) findViewById(R.id.tvFecha);

        if(usu.getFecha_nacimiento().length()>0){
            tvFecha2.setText(usu.getFecha_nacimiento());
        }

        if(usu.getNombre().toString().length()>0) {
            etN.setText(usu.getNombre());
        }
        if(usu.getApellidos().length()>0) {
            etA.setText(usu.getApellidos());
        }
//        etF.setText(usu.getFecha_nacimiento());
        if(usu.getCodigo_postal().length()>0) {
            etC.setText(usu.getCodigo_postal() + "");
        }
        if(usu.getLocalidad().length()>0) {
            etL.setText(usu.getLocalidad());
        }

        btEdit.setVisibility(View.GONE);
        btGuardar.setVisibility(View.VISIBLE);
        btGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nombre = etN.getText().toString();
                String apellidos = etA.getText().toString();
                String codigo = etC.getText().toString();
                String loca = etL.getText().toString();
                String f = tvFecha2.getText().toString();

                guardar(nombre, apellidos, codigo, loca, f);
            }
        });

    }

    public void guardar(String nom, String ape, String cod, String lo, String fecha){

        String cod2 = String.valueOf(usu.getCodigo_postal());

        boolean aux = true;

//        Toast.makeText(this, cod.length() + " -- " + cod2, Toast.LENGTH_SHORT).show();

        if(nom.length()>0 || ape.length()>0 || cod.length()>0 || lo.length()>0 || !fecha.equals("DD/MM/YYYY")) {

            if (!nom.equals(usu.getNombre()) || !ape.equals(usu.getApellidos()) || (!cod.equals(cod2) && cod.length()>0) || !lo.equals(usu.getLocalidad()) || (!fecha.equals(usu.getFecha_nacimiento()) || usu.getFecha_nacimiento().length()==0)) {

                aux = false;

                JSONObject respuesta = new JSONObject();
                JSONObject enviar = new JSONObject();

                try {

                    //recibe la respuesta del servidor
                    enviar.put(Tags.RESULTADO, "OK");
                    enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
                    enviar.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));

                    if(!fecha.equals(usu.getFecha_nacimiento()) && !fecha.equals("DD/MM/YYYY")){
                        enviar.put(Tags.FECHA, fecha);
//                        Toast.makeText(this, "fecha", Toast.LENGTH_SHORT).show();
                    }

                    if (!nom.equals(usu.getNombre())) {
                        enviar.put(Tags.NOMBRE, nom);
//                        Toast.makeText(this, "nombre", Toast.LENGTH_SHORT).show();
                    }
                    if (!ape.equals(usu.getApellidos())) {
                        enviar.put(Tags.APELLIDOS, ape);
//                        Toast.makeText(this, "apellidos", Toast.LENGTH_SHORT).show();
                    }
                    if (!cod.equals(cod2) && cod.length()>0) {
                        enviar.put(Tags.CODIGO_POSTAL, String.valueOf(cod));
//                        Toast.makeText(this, "codigo postal", Toast.LENGTH_SHORT).show();
                    }
                    if (!lo.equals(usu.getLocalidad())) {
                        enviar.put(Tags.LOCALIDAD, lo);
//                        Toast.makeText(this, "localidad", Toast.LENGTH_SHORT).show();
                    }

                    respuesta = JSONUtil.hacerPeticionServidor("java/set_prefil/", enviar);

//                    Log.i("NULL:", "-----------------------------------------");
//                    Log.i("NULL:", respuesta.getString(Tags.RESULTADO));
//                    Log.i("NULL:", respuesta.toString());
                    //                Toast.makeText(this, "ENTRA", Toast.LENGTH_SHORT).show();
                    //comprueba de que se realizo con exito
                    if (respuesta.getString(Tags.RESULTADO).contains("ok")) {

//                        Log.e("RESULTADO", String.valueOf(usu.getCodigo_postal()));

                        cargarPerfil();

                        Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show();

                    }

                } catch (JSONException e) {

                    e.printStackTrace();
                    Toast.makeText(this, "No se ha podido guardar", Toast.LENGTH_SHORT).show();
                }

            }
        }

        if(aux) {
            Toast.makeText(this, "No se ha modificado nada", Toast.LENGTH_SHORT).show();
        }

        ll1.setVisibility(View.VISIBLE);
        ll2.setVisibility(View.VISIBLE);
        ll3.setVisibility(View.VISIBLE);
        ll4.setVisibility(View.VISIBLE);

        lN.setVisibility(View.VISIBLE);
        lF.setVisibility(View.VISIBLE);
        lC.setVisibility(View.VISIBLE);
        lL.setVisibility(View.VISIBLE);

        tN.setVisibility(View.GONE);
        tA.setVisibility(View.GONE);
        tC.setVisibility(View.GONE);
        tL.setVisibility(View.GONE);
        rlFecha.setVisibility(View.GONE);

        btEdit.setVisibility(View.VISIBLE);
        btGuardar.setVisibility(View.GONE);
    }

    public void cerrarSesion(){

        JSONObject respuesta = new JSONObject();
        JSONObject enviar = new JSONObject();
//        Log.i("ENTRAAAAA:","-----------------------------------------");
        try {
            //recibe la respuesta del servidor
            enviar.put(Tags.RESULTADO,"OK");
            enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
            enviar.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));
            respuesta = JSONUtil.hacerPeticionServidor("java/logout/",enviar);

//            Log.i("NULL:","-----------------------------------------");
//            Log.i("NULL:",respuesta.getString(Tags.RESULTADO));
//            Log.i("NULL:",respuesta.toString());

            Usuario.cerrarSesion(this);

            //comprueba de que se realizo con exito
            if(respuesta.getString(Tags.RESULTADO).contains("ok")){
//                Log.e("Deslogueado","deslogueado");
                finish();
            }else{
                Toast.makeText(this, "Error de sesion", Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {

            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(Usuario.getToken(getApplicationContext()).length()<=0) {
            Intent inicio = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(inicio);
        }
    }

    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");

//        DialogFragment newFragment2 = new DialogFragment();
//        newFragment.show(getSupportFragmentManager(), "datePicker");
    }
}
