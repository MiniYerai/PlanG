package es.plang.ruben.plang.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutionException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import android.os.Environment;

import es.plang.ruben.plang.DelImages;

public class DescargarImagen {

	public static void guardaImagen(Bitmap b, String picName,
									String carpeta) {
		FileOutputStream fos;
		File f = new File(Environment.getExternalStorageDirectory()
				+ "/planG/" + carpeta);
		if (!f.exists()) {
			f.mkdirs();
		}
		f = new File(Environment.getExternalStorageDirectory()
				+ "/planG/" + carpeta + "/" + picName);
		try {
			fos = new FileOutputStream(f);
			b.compress(Bitmap.CompressFormat.PNG, 100, fos);
			fos.close();
		} catch (FileNotFoundException e) {
			// Log.d("IMAGEN NO ENCONTRADA", "file not found");
			e.printStackTrace();
		} catch (IOException e) {
			// Log.d("IO", "io exception");
			e.printStackTrace();
		}
	}
	public static Bitmap comprobarImagen(String picName, String carpeta, long pk) {

		if(pk>=0) {
			DelImages delImages = new DelImages();
			delImages.imagesdel(pk, picName);
		}
		File f = new File(Environment.getExternalStorageDirectory()
				+ "/planG/" + carpeta + "/" + picName);
		if (f.exists()) {
			Bitmap imagen_guardada = BitmapFactory.decodeFile(f
					.getAbsolutePath());
			return imagen_guardada;
		} else {
			return null;
		}
	}

	public static Bitmap descargarImagen(String url){
		Descarga d=new Descarga();
		d.execute(url);
		Bitmap b=null;
		try {
			b=d.get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
		
	}
	

	private static class Descarga extends AsyncTask<String, Void, Bitmap> {
		URL newurl;
		@Override
		protected Bitmap doInBackground(String... params) {
			Bitmap mIcon_val = null;
			try {
				newurl = new URL(params[0]);
				mIcon_val = BitmapFactory.decodeStream(newurl.openConnection()
						.getInputStream());

			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return mIcon_val;
		}

	}

//	public static Bitmap comprobarImagen(String picName, String carpeta,String url) {
//		File f = new File(Environment.getExternalStorageDirectory()+ "/ActividadesG/" + carpeta + "/" + picName);
//		if (f.exists()) {
//			Bitmap imagen_guardada = BitmapFactory.decodeFile(f.getAbsolutePath());
//			return imagen_guardada;
//		} else {
//
//            File f2 = guardaImagen(descargarImagen(url),picName,carpeta);
//            if(f2 != null) {
//                Bitmap imagen_guardada = BitmapFactory.decodeFile(f2.getAbsolutePath());
//                return imagen_guardada;
//            }else{
//                return null;
//            }
//		}
//	}
//    public static Bitmap comprobarImagen2(String picName, String carpeta) {
//        File f = new File(Environment.getExternalStorageDirectory()+ "/ActividadesG/" + carpeta + "/" + picName);
//        if (f.exists()) {
//            Bitmap imagen_guardada = BitmapFactory.decodeFile(f.getAbsolutePath());
//            return imagen_guardada;
//        } else {
//            return null;
//        }
//    }

//    public static File guardaImagen(Bitmap b, String picName, String carpeta) {
//        FileOutputStream fos;
//        File f = new File(Environment.getExternalStorageDirectory()+ "/ActividadesG/" + carpeta);
//        if (!f.exists()) {
//            f.mkdirs();
//        }
//        f = new File(Environment.getExternalStorageDirectory()+ "/ActividadesG/" + carpeta + "/" + picName);
//        try {
//            fos = new FileOutputStream(f);
//            b.compress(Bitmap.CompressFormat.PNG, 100, fos);
//            fos.close();
//            return f;
//        } catch (FileNotFoundException e) {
//            // Log.d("IMAGEN NO ENCONTRADA", "file not found");
//            e.printStackTrace();
//            return null;
//        } catch (IOException e) {
//            // Log.d("IO", "io exception");
//            e.printStackTrace();
//            return null;
//        }
//    }
}
