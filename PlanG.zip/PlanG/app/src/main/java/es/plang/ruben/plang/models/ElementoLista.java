package es.plang.ruben.plang.models;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import es.plang.ruben.plang.BDInterna.ContratoBD;

/*
 * Created by Ruben on 19/10/2016.
 */

public class ElementoLista implements Parcelable {

    private long id;
    private String color;

    //CREADOR POR DEFECTO
    public ElementoLista(){ this(0,null);}

    public ElementoLista(long id, String texto){
        this.id=id;
        this.color=texto;
    }
    //PARCELABLE
    protected ElementoLista(Parcel in) {
        id = in.readLong();
        color = in.readString();
    }


    public static final Creator<ElementoLista> CREATOR = new Creator<ElementoLista>() {
        @Override
        public ElementoLista createFromParcel(Parcel in) {
            return new ElementoLista(in);
        }

        @Override
        public ElementoLista[] newArray(int size) {
            return new ElementoLista[size];
        }
    };

    //GETS Y SETS


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String texto) {
        this.color = texto;
    }

    public static Creator<ElementoLista> getCREATOR() {
        return CREATOR;
    }

    public ContentValues getCV(){ return this.getCV(false);}

    public ContentValues getCV(boolean withId){
        ContentValues valores = new ContentValues();

        if(withId){
            valores.put(ContratoBD.TablaConfig._ID, this.getId());
        }
        valores.put(ContratoBD.TablaConfig.COLOR, this.getColor());

        return valores;
    }

    public static ElementoLista getLista(Cursor c){
        ElementoLista objeto = new ElementoLista();

        objeto.setId(c.getLong(c.getColumnIndex(ContratoBD.TablaConfig._ID)));
        objeto.setColor(c.getString(c.getColumnIndex(ContratoBD.TablaConfig.COLOR)));

        return objeto;
    }

    public String toString(){

        return "ElementoLista{" + "id = " + id +", color = '" + color + '\'' + "}";
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeLong(id);
        dest.writeString(color);
    }
}
