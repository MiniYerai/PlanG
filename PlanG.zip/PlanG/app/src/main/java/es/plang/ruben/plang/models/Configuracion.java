package es.plang.ruben.plang.models;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

import es.plang.ruben.plang.BDInterna.Ayudante;
import es.plang.ruben.plang.BDInterna.ContratoBD;

/**
 * Created by Ruben on 04/06/2017.
 */

public class Configuracion {//implements Parcelable
    long id;
    String color;
    private ArrayList<ElementoLista> arrLista;

    public Configuracion(long id, String color) {
        this.id=id;
        this.color = color;
    }
//    public static Creator<Configuracion> getCREATOR() {
//        return CREATOR;
//    }
//
//    public static final Creator<Configuracion> CREATOR = new Creator<Configuracion>() {
//        @Override
//        public Configuracion createFromParcel(Parcel in) {
//            return new Configuracion(in);
//        }
//
//        @Override
//        public Configuracion[] newArray(int size) {
//            return new Configuracion[size];
//        }
//    };
//    public void setArrayLista(ArrayList<ElementoLista> arrayLista) {
//
//        this.arrLista =arrayLista;
//    }
//
//    public static final Creator<Configuracion> CREATOR = new Creator<Configuracion>() {
//        @Override
//        public Configuracion createFromParcel(Parcel in) {
//            return new Configuracion(in);
//        }
//
//        @Override
//        public Configuracion[] newArray(int size) {
//            return new Configuracion[size];
//        }
//    };

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

//    public ArrayList<ElementoLista> getArrLista() {
//        return arrLista;
//    }
//
//    public void setArrLista(ArrayList<ElementoLista> arrLista) {
//        this.arrLista = arrLista;
//    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

//    public ContentValues toContentValues() {
//        ContentValues values = new ContentValues();
//        values.put(ContratoBD.TablaConfig.COLOR, color);
//        return values;
//    }
//
//    @Override
//    public int describeContents() {
//        return 0;
//    }
//
//    @Override
//    public void writeToParcel(Parcel dest, int flags) {
//        dest.writeString(color);
//    }

    public ContentValues toContentValues() {
        ContentValues values = new ContentValues();
        values.put(ContratoBD.TablaConfig._ID, id);
        values.put(ContratoBD.TablaConfig.COLOR, color);
        return values;
    }
}
