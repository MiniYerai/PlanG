package es.plang.ruben.plang.utils;

import android.util.Log;
import android.widget.EditText;

import java.util.regex.Pattern;

/**
 * Created by Ruben on 23/04/2017.
 */

public class Validar {

    public boolean cero(EditText et,String txt, String ms){

        if(txt.length()>0){
            return true;
        }else{
            et.setError(ms);
            return false;
        }
    }

    public boolean correo(EditText et,String txt, String ms){

        Boolean b = Pattern.matches("^[0-9a-zA-Z]+[@]{1}[a-zA-Z]+[.]{1}[a-zA-Z]+", txt);
        if(b){
            return true;
        }else{
            et.setError(ms);
            return false;
        }
    }
    public boolean correoLogin(String txt){

        Boolean b = Pattern.matches("^[0-9a-zA-Z]+[@]{1}[a-zA-Z]+[.]{1}[a-zA-Z]+", txt);

        if(b){
            return true;
        }else{
            return false;
        }
    }
    public boolean password(EditText et,String txt){
        Boolean b = Pattern.matches("^[^0-9a-zA-Z]+$", txt);
        if(txt.length()>=4){
            if(!b){
                return true;
            }else{
                et.setError("La contraseña no debe contener caracteres raros");
            }
        }else{
            et.setError("Contraseña demasiado corta");
        }
        return false;
    }
    public boolean passwordrepeat(EditText et,String txt,String txt2){

        if(txt.compareTo(txt2)==0){
            return true;
        }else{
            et.setError("Las contraseñas no coinciden");
        }
        return false;
    }

    public boolean passwordLogin(String txt){
        Boolean b = Pattern.matches("^[^0-9a-zA-Z]+$", txt);
        if(txt.length()>=4){
            if(!b){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    public boolean postal(EditText et,String txt){

//        if(txt.compareTo(txt2)==0){
//            return true;
//        }else{
//            et.setError("Las contraseñas no coinciden");
//        }
        return false;
    }
}
