package es.plang.ruben.plang;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import es.plang.ruben.plang.PeticionBD.JSONUtil;
import es.plang.ruben.plang.PeticionBD.Tags;
import es.plang.ruben.plang.models.Actividad;
import es.plang.ruben.plang.models.Tipo;
import es.plang.ruben.plang.models.Usuario;
import es.plang.ruben.plang.utils.DatePickerFragment;
import es.plang.ruben.plang.utils.TimePickerFragment;

public class EditActividad extends AppCompatActivity {

    String id="";
    Actividad actividad;
    String t = "1";
    private static final String DIALOG_TIME= "DialogTime";
    ArrayList<Tipo> listadoTipos;
    String tipo="";
    public boolean nuevo = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //elimina la barra existente
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_edit_actividad);

        if(Usuario.getToken(getApplicationContext()).length()>0) {
            t = Usuario.getToken(getApplicationContext()).substring(0, 1);
            if(!t.equals("0")){
                Intent inicio = new Intent(getApplicationContext(), new MainActivity().getClass());
                startActivity(inicio);
            }
        }else{
            Intent inicio = new Intent(getApplicationContext(), new MainActivity().getClass());
            startActivity(inicio);
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //boton de atras
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        //boton de atras
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Bundle extras = getIntent().getExtras();

        if(extras!=null) {
            id = getIntent().getStringExtra("id");
            cargarActividad();
            mostrarActividad();
        }else{
            nuevo = true;
        }
        lista_tipos();
    }

    //envia el pk de la actividad y le devuelve los datos
    private void cargarActividad() {
        //Creamos el JSON que vamos a mandar al servidor
        JSONObject jsonConsulta = new JSONObject();
        try {
            jsonConsulta.put(Tags.ID, id+"");
            jsonConsulta.put(Tags.RESULTADO, "ok");
            jsonConsulta.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));
            jsonConsulta.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        //Hacemos petición de la actividad
        jsonConsulta = JSONUtil.hacerPeticionServidor("java/get_actividad_edit/", jsonConsulta);
//        Log.i("MOSTRANDO JSON", String.valueOf(jsonConsulta));
        try {
            String p = jsonConsulta.getString(Tags.RESULTADO);

            //En caso de que conecte con el servidor
            if (p.contains(Tags.OK)) {
//                Log.e("JSON ACTIVIDAD",p);
                actividad = new Actividad(jsonConsulta);
            }
            //resultado falla por otro error
            else if (p.contains(Tags.ERROR)) {
                String msg = jsonConsulta.getString(Tags.MENSAJE);
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void mostrarActividad(){

        final ViewHolder holder = new ViewHolder();


//        Toast.makeText(this, actividad.getTitulo(), Toast.LENGTH_SHORT).show();
        holder.fecha= (TextView) findViewById(R.id.tvFecha);
//        TextView asistentes= (TextView) findViewById(R.id.tvVisitas);
        holder.hora= (TextView) findViewById(R.id.tvHora);
        holder.precio= (EditText) findViewById(R.id.etPrecio);
        holder.lugar= (EditText) findViewById(R.id.etLugar);
        holder.desc= (EditText) findViewById(R.id.acDescripcion);
        holder.titulo = (EditText) findViewById(R.id.etTitulo);
//        CollapsingToolbarLayout img = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
//
        String horaM = actividad.getHora().substring(0, actividad.getHora().length()-3);
//
//        Bitmap bmp = DescargarImagen.comprobarImagen(actividad.getPk()+"", "actividades");
//
//        if (bmp != null) {
//
//            Drawable d = new BitmapDrawable(getResources(), bmp);
//
//            Log.e("DRAWABLE",d.toString());
//            img.setBackground(d);
//        }
        holder.titulo.setText(actividad.getTitulo());
        holder.fecha.setText(actividad.getFecha());
//        asistentes.setText(actividad.getNumero_asistentes());
        holder.hora.setText(horaM);
        holder.precio.setText(actividad.getPrecio());
        holder.lugar.setText(actividad.getLugar());
//        org.setText(actividad.getOrganizador());
        holder.desc.setText(actividad.getDescripcion());
    }

    private class ViewHolder {

        private TextView fecha;
        private TextView hora;
        private EditText precio;
        private EditText lugar;
        private EditText desc;
        private EditText titulo;
    }

    //Se descarga la lista de tipos y la carga
    public void lista_tipos(){
        //json que devuelve
        JSONObject respuesta = new JSONObject();
        //json que envia
        JSONObject enviar = new JSONObject();

        try {
            //Hace peticion al servidor
            enviar.put(Tags.RESULTADO,Tags.OK);
            enviar.put(Tags.USUARIO_ID,Usuario.getID(getApplicationContext()));
            enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
            enviar.put(Tags.STAFF,"YES");

            //recibe respuesta
            respuesta = JSONUtil.hacerPeticionServidor("java/tipos_all/", enviar);

            //comprueba de que se realizo con exito
            if(respuesta.getString(Tags.RESULTADO).contains("ok")){

                JSONArray arrayTipos = respuesta.getJSONArray("tipos");
                Tipo temp;

                if (arrayTipos != null) {
                    listadoTipos = new ArrayList<Tipo>();

                    Spinner sp = (Spinner) findViewById(R.id.stipo);
                    List<String> list = new ArrayList<String>();

                    if(id.length()>0) {
                        list.add(actividad.getTipo_actividad());
                        for (int i = 0; i < arrayTipos.length(); i++) {

                            temp = new Tipo(arrayTipos.getJSONObject(i));

                            if(!temp.getNombre().equals(actividad.getTipo_actividad())) {
//                                Log.e("TIPOS", temp.getNombre());
                                list.add(temp.getNombre());
                            }
                        }
                    }else {

                        for (int i = 0; i < arrayTipos.length(); i++) {

                            temp = new Tipo(arrayTipos.getJSONObject(i));

                            list.add(temp.getNombre());

                        }
                    }

                    ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                            android.R.layout.simple_spinner_item, list);
                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    sp.setAdapter(dataAdapter);
                    sp.setOnItemSelectedListener(
                            new AdapterView.OnItemSelectedListener() {
                                public void onItemSelected(AdapterView<?> parent,
                                                           android.view.View v, int position, long id) {
                                    tipo = parent.getItemAtPosition(position).toString();
                                }

                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                }
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    public void guardar(){

        final ViewHolder holder = new ViewHolder();

        holder.fecha = (TextView) findViewById(R.id.tvFecha);
        holder.hora = (TextView) findViewById(R.id.tvHora);
        holder.precio = (EditText) findViewById(R.id.etPrecio);
        holder.lugar = (EditText) findViewById(R.id.etLugar);
        holder.desc = (EditText) findViewById(R.id.acDescripcion);
        holder.titulo = (EditText) findViewById(R.id.etTitulo);

        String fecha = holder.fecha.getText().toString();
        String hora = holder.hora.getText().toString();
        String lugar = holder.lugar.getText().toString();
        String desc = holder.desc.getText().toString();
        String titulo = holder.titulo.getText().toString();

        TextView tvE1 = (TextView) findViewById(R.id.tvFechaE);
        TextView tvE2 = (TextView) findViewById(R.id.tvHoraE);
        tvE1.setVisibility(View.INVISIBLE);
        tvE2.setVisibility(View.INVISIBLE);

        if(!fecha.equals("DD/MM/YYYY") && !hora.equals("HH:MM") && lugar.length()>0 && desc.length()>0 && titulo.length()>0) {

            if (id.length() > 0) {

                Boolean aux = false;

                //Creamos el JSON que vamos a mandar al servidor
                JSONObject jsonConsulta = new JSONObject();
                try {
                    jsonConsulta.put(Tags.ID, id + "");
                    jsonConsulta.put(Tags.RESULTADO, "ok");

                    jsonConsulta.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));
                    jsonConsulta.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));

                    if (!tipo.equals(actividad.getTipo_actividad())) {
                        jsonConsulta.put(Tags.TIPO, tipo);
                        aux = true;
                    }

                    String horaM = actividad.getHora().substring(0, actividad.getHora().length() - 3);

                    if (!holder.hora.getText().toString().equals(horaM)) {

                        jsonConsulta.put(Tags.HORA, holder.hora.getText().toString());
                        aux = true;
                    }
                    double precio = 0;
                    double precioNuevo = Double.parseDouble(holder.precio.getText().toString());
                    if (precioNuevo > 0) {
                        precio = precioNuevo;
                    }
                    double precio2=Double.parseDouble(actividad.getPrecio());
                    if (precio!=precio2) {

                        precio = Math.round(precio * 100.0) / 100.0;
                        jsonConsulta.put(Tags.PRECIO, precio);
                        aux = true;
                    }
                    if (!holder.lugar.getText().toString().equals(actividad.getLugar())) {

                        jsonConsulta.put(Tags.LUGAR, holder.lugar.getText().toString());
                        aux = true;
                    }
                    if (!holder.desc.getText().toString().equals(actividad.getDescripcion())) {
                        jsonConsulta.put(Tags.DESCRIPCION, holder.desc.getText().toString());
                        aux = true;
                    }
                    if (!holder.titulo.getText().toString().equals(actividad.getTitulo())) {
                        jsonConsulta.put(Tags.TITULO, holder.titulo.getText().toString());
                        aux = true;
                    }
                    if (!holder.fecha.getText().toString().equals(actividad.getFecha())) {
                        jsonConsulta.put(Tags.FECHA, holder.fecha.getText().toString());
                        aux = true;
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (aux) {

                    //            Hacemos petición de la actividad
                    jsonConsulta = JSONUtil.hacerPeticionServidor("java/set_actividad_edit/", jsonConsulta);
//                    Log.i("MOSTRANDO JSON", String.valueOf(jsonConsulta));
                    try {
                        String p = jsonConsulta.getString(Tags.RESULTADO);

                        //En caso de que conecte con el servidor
                        if (p.contains(Tags.OK)) {
//                            Log.e("JSON ACTIVIDAD", p);
                            actividad = new Actividad(jsonConsulta);

                        }
                        //resultado falla por otro error
                        else if (p.contains(Tags.ERROR)) {
                            String msg = jsonConsulta.getString(Tags.MENSAJE);
                            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Toast.makeText(this, "Se ha guardado", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "No ha habido cambios", Toast.LENGTH_SHORT).show();
                }
            } else {

                //Creamos el JSON que vamos a mandar al servidor
                JSONObject jsonConsulta = new JSONObject();
                try {
                    jsonConsulta.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));
                    jsonConsulta.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
                    jsonConsulta.put(Tags.RESULTADO, "ok");

                    jsonConsulta.put(Tags.TIPO, tipo);

                    jsonConsulta.put(Tags.HORA, holder.hora.getText().toString());

                    double precio = 0;

                    if(holder.precio.getText().toString().length()>0) {
                        precio = Float.parseFloat(holder.precio.getText().toString());
                        precio = Math.round(precio * 100.0) / 100.0;
                    }
                    jsonConsulta.put(Tags.PRECIO, precio);

                    jsonConsulta.put(Tags.LUGAR, holder.lugar.getText().toString());

                    jsonConsulta.put(Tags.DESCRIPCION, holder.desc.getText().toString());

                    jsonConsulta.put(Tags.TITULO, holder.titulo.getText().toString());

                    jsonConsulta.put(Tags.FECHA, holder.fecha.getText().toString());

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                //            Hacemos petición de la actividad
                jsonConsulta = JSONUtil.hacerPeticionServidor("java/add_actividad/", jsonConsulta);
//                Log.i("MOSTRANDO JSON", String.valueOf(jsonConsulta));
                try {
                    String p = jsonConsulta.getString(Tags.RESULTADO);

                    //En caso de que conecte con el servidor
                    if (p.contains(Tags.OK)) {
//                        Log.e("JSON ACTIVIDAD", p);

                        if(id.length()==0) {
                            createAlertImage(holder.titulo.getText().toString(),holder.fecha.getText().toString());

                        }

//                        Toast.makeText(this, "Se ha creado correctamente", Toast.LENGTH_SHORT).show();
//                        finish();
                    }
                    //resultado falla por otro error
                    else if (p.contains(Tags.ERROR)) {
                        String msg = jsonConsulta.getString(Tags.MENSAJE);
                        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }else{

            if(titulo.length()<=0){
                holder.titulo.setError("Titulo obligatorio");
                Toast.makeText(this, "Titulo Obligatorio", Toast.LENGTH_SHORT).show();
            }else if(fecha.equals("DD/MM/YYYY")){
                tvE1.setText("Fecha obligatoria");
                tvE1.setVisibility(View.VISIBLE);
                tvE1.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.gastronomia));
                Toast.makeText(this, "Fecha Obligatoria", Toast.LENGTH_SHORT).show();
            }else if(hora.equals("HH:MM")){
                tvE2.setText("Hora bligatoria");
                tvE2.setVisibility(View.VISIBLE);
                tvE2.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.gastronomia));
                Toast.makeText(this, "Hora Obligatoria", Toast.LENGTH_SHORT).show();
            }else if(lugar.length()<=0){
                holder.lugar.setError("Lugar obligatorio");
                Toast.makeText(this, "Lugar Obligatorio", Toast.LENGTH_SHORT).show();
            }else if(desc.length()<=0){
                holder.desc.setError("Descripcion obligatoria");
                Toast.makeText(this, "Descripcion Obligatoria", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //crea la alerta de suspender
    public void createAlertImage(final String nombre, final String fecha){

        //Crea el alert dialog
        android.app.AlertDialog.Builder dialogo = new android.app.AlertDialog.Builder(this);
        dialogo.setTitle("Contacto con el Administrador");
        dialogo.setMessage("Para añadir una imagen a la actividad creada mandenos un correo a esta dirección rubengirela@gmail.com");

        dialogo.setCancelable(false);
        dialogo.setPositiveButton("Enviar Imagen", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo, int id) {
//                 Reemplazamos el email por algun otro real
                String[] to = { "info@plang.com", "" };
                String[] cc = { "" };
                enviar(to, cc, "Imagen para la actividad ("+nombre+")",
                        "Le envio la imagen de la actividad "+nombre+" con la fecha de inauguración "+fecha);
                finish();
            }
        });
        dialogo.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo, int id) {
                finish();
            }
        });
        dialogo.show();
    }

    private void enviar(String[] to, String[] cc,
                        String asunto, String mensaje) {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        //String[] to = direccionesEmail;
        //String[] cc = copias;
        emailIntent.putExtra(Intent.EXTRA_EMAIL, to);
        emailIntent.putExtra(Intent.EXTRA_CC, cc);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, asunto);
        emailIntent.putExtra(Intent.EXTRA_TEXT, mensaje);
        emailIntent.setType("message/rfc822");
        startActivity(Intent.createChooser(emailIntent, "Email "));
    }

    // muenu del action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_actividad, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.action_settings:
                Toast.makeText(this, "Proximamente estara", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_log:
                if(Usuario.getToken(getApplicationContext()).length()>0){
                    Intent p = new Intent(getApplicationContext(), new Perfil().getClass());
                    startActivity(p);
                }else {
                    Intent login = new Intent(getApplicationContext(), new Login().getClass());
                    startActivity(login);
                }
                return true;
            case R.id.action_save:
                guardar();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");

//        DialogFragment newFragment2 = new DialogFragment();
//        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    public void showTimePickerDialog(View v) {
//        DialogFragment newFragment = new DatePickerFragment();
//        newFragment.show(getSupportFragmentManager(), "datePicker");

//        FragmentManager manager = getSupportFragmentManager();
//        TimePickerFragment dialog = new TimePickerFragment();
//        dialog.show(manager,DIALOG_TIME);

        DialogFragment newFragment2 = new TimePickerFragment();
        newFragment2.show(getSupportFragmentManager(), "timePicker");
    }

    @Override
    protected void onResume() {
        super.onResume();

        Bundle extras = getIntent().getExtras();

        if(extras!=null) {
            id = getIntent().getStringExtra("id");
            cargarActividad();
            mostrarActividad();
        }
        lista_tipos();
    }
}

