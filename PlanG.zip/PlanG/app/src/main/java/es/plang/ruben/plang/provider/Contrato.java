package es.plang.ruben.plang.provider;

import android.net.Uri;

import org.json.JSONObject;

import java.util.UUID;

/**
 * Created by Ruben on 05/04/2017.
 */

public class Contrato {

    interface ColumnasActividad {
        String ID_ACTIVIDAD = "idActividad"; // Pk
        String NOMBRE  = "nombre";
        String UBICACION = "ubicacion";
        String DESCRIPCION = "descripcion";
        String PRECIO = "precio";
        String URL_IMAGEN ="urlImagen";
    }

    // Autoridad del Content Provider
    public final static String AUTORIDAD = "es.plang.ruben.plang";

    // Uri base
    public final static Uri URI_CONTENIDO_BASE = Uri.parse("content://" + AUTORIDAD);


    /**
     * Controlador de la tabla "alquiler"
     */
    public static class Actividad implements ColumnasActividad {

        public static final Uri URI_CONTENIDO =
                URI_CONTENIDO_BASE.buildUpon().appendPath(RECURSO_ACTIVIDAD).build();

        public final static String MIME_RECURSO =
                "vnd.android.cursor.item/vnd." + AUTORIDAD + "/" + RECURSO_ACTIVIDAD;

        public final static String MIME_COLECCION =
                "vnd.android.cursor.dir/vnd." + AUTORIDAD + "/" + RECURSO_ACTIVIDAD;


        /**
         * Construye una {@link Uri} para el {@link #ID_ACTIVIDAD} solicitado.
         */
        public static Uri construirUriActividad(String idActividad) {
            return URI_CONTENIDO.buildUpon().appendPath(idActividad).build();
        }

        public static String generarIdActividad() {
            return "A-" + UUID.randomUUID();
        }

        public static String obtenerIdActividad(Uri uri) {
            return uri.getLastPathSegment();
        }
    }

    // Recursos
    public final static String RECURSO_ACTIVIDAD = "actividades";
}
