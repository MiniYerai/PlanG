package es.plang.ruben.plang.BDInterna;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import es.plang.ruben.plang.models.Configuracion;

/**
 * Created by Ruben on 04/06/2017.
 */

public class Ayudante extends SQLiteOpenHelper {

    private static final int VERSION = 1;

    public Ayudante(Context context) {
        super(context, ContratoBD.BASEDATOS, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {//crea la base de datos
        String sql;
        sql="create table if not exists " + ContratoBD.TablaConfig.TABLA +
                " (" +
                ContratoBD.TablaConfig._ID + " integer primary key autoincrement , " +
                ContratoBD.TablaConfig.COLOR + " text, " +
                ");";

        Log.e("base datos",sql);
        db.execSQL(sql);

        // Contenedor de valores
        ContentValues values = new ContentValues();

//        // Pares clave-valor
//        values.put(ContratoBD.TablaConfig.COLOR, "morado");
//        values.put(ContratoBD.TablaConfig.COLOR, "naranja");
//        values.put(ContratoBD.TablaConfig.COLOR, "rojo");
//        values.put(ContratoBD.TablaConfig.COLOR, "azul");
//        values.put(ContratoBD.TablaConfig.COLOR, "negro");
//
//        // Insertar...
//        db.insert(ContratoBD.TablaConfig.TABLA, null, values);
    }

    private void mockData(SQLiteDatabase sqLiteDatabase) {
        mockConf(sqLiteDatabase, new Configuracion(1,"morado"));
//        mockConf(sqLiteDatabase, new Configuracion(2,"naranja"));
//        mockConf(sqLiteDatabase, new Configuracion(3,"rojo"));
//        mockConf(sqLiteDatabase, new Configuracion(4,"azul"));
//        mockConf(sqLiteDatabase, new Configuracion(5,"negro"));
    }
    public long mockConf(SQLiteDatabase db, Configuracion conf) {
        return db.insert(
                ContratoBD.TablaConfig.TABLA,
                null,
                conf.toContentValues());
    }

//    public long saveSettings(Configuracion conf) {
//        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
//
//        return sqLiteDatabase.insert(
//                ContratoBD.TablaConfig.TABLA,
//                null,
//                conf.toContentValues());
//
//    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS" + ContratoBD.TablaConfig.TABLA);
        // Creating tables again
        onCreate(db);
    }
}
