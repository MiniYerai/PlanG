package es.plang.ruben.plang;

import android.annotation.TargetApi;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import es.plang.ruben.plang.BDInterna.Ayudante;
import es.plang.ruben.plang.BDInterna.ContratoBD;
import es.plang.ruben.plang.PeticionBD.JSONUtil;
import es.plang.ruben.plang.PeticionBD.Tags;
import es.plang.ruben.plang.models.Actividad;
import es.plang.ruben.plang.models.Configuracion;
import es.plang.ruben.plang.models.Usuario;
import es.plang.ruben.plang.utils.DescargarImagen;

/**
 * Created by Ruben on 04/06/2017.
 */

public class ActivityConfiguracion extends AppCompatActivity {

    String t = "1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //elimina la barra existente
//        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.temporal);

        if(Usuario.getToken(getApplicationContext()).length()>0) {
            t = Usuario.getToken(getApplicationContext()).substring(0, 1);
            if(!t.equals("0")){
                Intent inicio = new Intent(getApplicationContext(), new MainActivity().getClass());
                startActivity(inicio);
            }
        }else{
            Intent inicio = new Intent(getApplicationContext(), new MainActivity().getClass());
            startActivity(inicio);
        }

//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//
//        //boton de atras
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);
//
//        //boton de atras
//        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });

//        List<Configuracion> conf = getAllColors();
//        Log.e("CONFIGURACION",conf.toString());

        //Abrimos la base de datos 'DBUsuarios' en modo escritura
        Ayudante ayudante = new Ayudante(this);

        SQLiteDatabase db = ayudante.getWritableDatabase();

        //Si hemos abierto correctamente la base de datos
        if(db != null)
        {
            //Insertamos 5 usuarios de ejemplo
            for(int i=1; i<=5; i++)
            {
                //Generamos los datos
                String nombre = "color" + i;

                //Insertamos los datos en la tabla Usuarios
                db.execSQL("INSERT INTO config (nombre) " +
                        "VALUES (" + nombre +"')");
            }

            //Cerramos la base de datos
            db.close();
        }
    }

    // Getting All
//    public List<Configuracion> getAllColors() {
//        List<Configuracion> confList = new ArrayList<Configuracion>();
//// Select All Query
//        String selectQuery = "SELECT * FROM " + ContratoBD.TablaConfig.TABLA;
//        Ayudante ayudante = new Ayudante(this);
//        SQLiteDatabase db = ayudante.getWritableDatabase();
//        Cursor cursor = db.rawQuery(selectQuery, null);
//// looping through all rows and adding to list
//        if (cursor.moveToFirst()) {
//            do {
//                Configuracion conf = new Configuracion();
//                conf.setId(Integer.parseInt(cursor.getString(0)));
//                conf.setColor(cursor.getString(1));
//// Adding contact to list
//                confList.add(conf);
//            } while (cursor.moveToNext());
//        }
//// return contact list
//        return confList;
//    }

    // muenu del action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_actividad, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.action_settings:
                Toast.makeText(this, "Proximamente estara", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_log:
                if(Usuario.getToken(getApplicationContext()).length()>0){
                    Intent p = new Intent(getApplicationContext(), new Perfil().getClass());
                    startActivity(p);
                }else {
                    Intent login = new Intent(getApplicationContext(), new Login().getClass());
                    startActivity(login);
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
