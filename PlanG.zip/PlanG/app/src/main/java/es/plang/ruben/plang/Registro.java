package es.plang.ruben.plang;

import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import es.plang.ruben.plang.PeticionBD.JSONUtil;
import es.plang.ruben.plang.PeticionBD.Tags;
import es.plang.ruben.plang.utils.DatePickerFragment;
import es.plang.ruben.plang.utils.Validar;

public class Registro extends AppCompatActivity {

    Button registrarse;
    EditText usuario;
    EditText email;
    EditText pass;
    EditText pass2;
    EditText codigoP;

    Validar v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro2);

        //barra de loguin
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //boton de atras
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        //boton de atras
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        v = new Validar();

        registrarse = (Button) findViewById(R.id.btRegistro);

        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comprobar();
            }
        });
    }

    // muenu del action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.action_settings:
                Toast.makeText(this, "Proximamente estara", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void comprobar(){

        usuario = (EditText) findViewById(R.id.etUsuario);
        email = (EditText) findViewById(R.id.etCorreo);
        pass = (EditText) findViewById(R.id.etPassword);
        pass2 = (EditText) findViewById(R.id.etPassword2);
        codigoP = (EditText) findViewById(R.id.etPostal);
        TextView fecha_n = (TextView) findViewById(R.id.tvFecha);

        String usu = usuario.getText().toString();
        String ema = email.getText().toString();
        String pas = pass.getText().toString();
        String pas2 = pass2.getText().toString();
        String cod = codigoP.getText().toString();
        String f_n = fecha_n.getText().toString();

        if(f_n.compareTo("DD/MM/YYYY")==0){
            f_n="nada";
        }

        //&& v.postal(codigoP,cod)
        if(v.cero(usuario,usu,"Usuario obligatorio")
        && v.correo(email,ema,"Correo invalido")
        && v.password(pass,pas)
        && v.passwordrepeat(pass2,pas,pas2)
        ){
            //json que devuelve
            JSONObject respuesta = new JSONObject();
            //json que envia
            JSONObject enviar = new JSONObject();

            try {

                //Hace peticion al servidor
                enviar.put(Tags.RESULTADO, Tags.OK);
                enviar.put(Tags.USUARIO, usu);
                enviar.put(Tags.CORREO, ema);
                enviar.put(Tags.PASSWORD, pas);
                enviar.put(Tags.CODIGO_POSTAL, cod);
                enviar.put(Tags.FECHA_NACIMIENTO, f_n);

                //recibe respuesta
                respuesta = JSONUtil.hacerPeticionServidor("java/registro/", enviar);
//                Log.i("RESPUESTA", respuesta.toString());

                //comprueba de que se realizo con exito
                if (respuesta.getString(Tags.RESULTADO).contains("ok")) {
                    Toast.makeText(this, "Registrado", Toast.LENGTH_SHORT).show();
                    finish();
                }else{
                    Toast.makeText(this, respuesta.getString(Tags.MENSAJE).toString(), Toast.LENGTH_LONG).show();
                }
            }catch (JSONException e){
                e.printStackTrace();
            }
        }
    }

    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }
}
