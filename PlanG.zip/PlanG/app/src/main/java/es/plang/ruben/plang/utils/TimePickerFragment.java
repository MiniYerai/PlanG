package es.plang.ruben.plang.utils;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

import es.plang.ruben.plang.R;

/**
 * Created by dreams on 18/05/17.
 */

public class TimePickerFragment extends DialogFragment
        implements TimePickerDialog.OnTimeSetListener {

    String hora="";

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        final Calendar c = Calendar.getInstance();
        int hours = c.get(Calendar.HOUR_OF_DAY);
        int minuts = c.get(Calendar.MINUTE);

        // Create a new instance of DatePickerDialog and return it
        return new TimePickerDialog(getActivity(),this,hours,minuts,true);
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

        // Do something with the date chosen by the user
        hora = hourOfDay + ":" + minute;

        TextView tv1= (TextView) getActivity().findViewById(R.id.tvHora);

        tv1.setText(hora);
    }

}
