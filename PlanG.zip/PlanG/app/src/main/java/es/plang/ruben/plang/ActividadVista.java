package es.plang.ruben.plang;

import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

import es.plang.ruben.plang.PeticionBD.JSONUtil;
import es.plang.ruben.plang.PeticionBD.Tags;
import es.plang.ruben.plang.models.Actividad;
import es.plang.ruben.plang.models.Usuario;
import es.plang.ruben.plang.utils.DescargarImagen;

public class ActividadVista extends AppCompatActivity {

    private String id;
    private Actividad actividad;
    Toolbar toolbar;
    String t = "1";
    public FloatingActionButton fab;
    TextView asistentes;
    private boolean aux = false;

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad);
        toolbar = (Toolbar) findViewById(R.id.toolbar);

        id = getIntent().getStringExtra("id");

//        Toast.makeText(ActividadVista.this, "ID "+id, Toast.LENGTH_SHORT).show();

        cargarActividad();
        mostrarActividad();

        if(Usuario.getToken(getApplicationContext()).length()>0) {
            t = Usuario.getToken(getApplicationContext()).substring(0, 1);
        }

        fab = (FloatingActionButton) findViewById(R.id.fab);

        if (t.equals("0")) {
            fab.setImageResource(R.drawable.ic_mode_edit_black_24dp);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent actividad = new Intent(getApplicationContext(), new EditActividad().getClass());
                    actividad.putExtra("id", id);
                    startActivity(actividad);
                }
            });
        } else {

            if(apuntado() || aux) {
                fab.setImageResource(R.drawable.ic_visibility_off_white_24dp);

            }else{
                fab.setImageResource(R.drawable.ic_remove_red_eye_white_24dp);
            }
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (checkUser()) {
                        asistir();
                    } else {
                        Intent login = new Intent(getApplicationContext(), new Login().getClass());
                        login.putExtra("id", id+"");
                        startActivity(login);
                    }
                }
            });
        }

//        Toast.makeText(this, actividad.isLista_asistentes()+"", Toast.LENGTH_SHORT).show();
        if (t.equals("0")) {
            if(actividad.isLista_asistentes()) {
                FloatingActionButton fabA = (FloatingActionButton) findViewById(R.id.btAsistentes);
                fabA.setVisibility(View.VISIBLE);
                fabA.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent asistentes = new Intent(getApplicationContext(), new ListaAsistentes().getClass());
                        asistentes.putExtra("id", id);
                        startActivity(asistentes);
                    }
                });
            }
        }
    }

    private boolean apuntado(){

        JSONObject respuesta = new JSONObject();
        JSONObject enviar = new JSONObject();

        try {

            //recibe la respuesta del servidor
            enviar.put(Tags.RESULTADO, "OK");
            enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
            enviar.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));
            enviar.put(Tags.ID, id);

            respuesta = JSONUtil.hacerPeticionServidor("java/apuntado/", enviar);

            if (respuesta.getString(Tags.RESULTADO).contains("ok")) {

                return true;

            }

        } catch (JSONException e) {

            e.printStackTrace();
            Toast.makeText(this, "Lo sentimos intentelo más tarde", Toast.LENGTH_SHORT).show();
        }

        return false;
    }

    private void asistir(){


        if(apuntado()) {
            JSONObject respuesta = new JSONObject();
            JSONObject enviar = new JSONObject();

            try {

                //recibe la respuesta del servidor
                enviar.put(Tags.RESULTADO, "OK");
                enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
                enviar.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));
                enviar.put(Tags.ID, id);

                respuesta = JSONUtil.hacerPeticionServidor("java/desapuntarse/", enviar);

                if (respuesta.getString(Tags.RESULTADO).contains("ok")) {

                    fab.setImageResource(R.drawable.ic_remove_red_eye_white_24dp);

                    asistentes = (TextView) findViewById(R.id.tvVisitas);

                    int asis = Integer.parseInt(asistentes.getText().toString());
                    asis--;
                    asistentes.setText(asis + "");
                    Toast.makeText(this, "Desapuntado", Toast.LENGTH_SHORT).show();
                    aux = true;

                }

            } catch (JSONException e) {

                e.printStackTrace();
                Toast.makeText(this, "Lo sentimos intentelo más tarde", Toast.LENGTH_SHORT).show();
            }
        }else{
            if(actividad.isSuspendido()){
                Toast.makeText(ActividadVista.this, "No se puede apuntarse", Toast.LENGTH_SHORT).show();
            }else {
                JSONObject respuesta = new JSONObject();
                JSONObject enviar = new JSONObject();

                try {

                    //recibe la respuesta del servidor
                    enviar.put(Tags.RESULTADO, "OK");
                    enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
                    enviar.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));
                    enviar.put(Tags.ID, id);

                    respuesta = JSONUtil.hacerPeticionServidor("java/asistir/", enviar);

                    if (respuesta.getString(Tags.RESULTADO).contains("ok")) {

                        fab.setImageResource(R.drawable.ic_visibility_off_white_24dp);

                        asistentes = (TextView) findViewById(R.id.tvVisitas);

                        int asis = Integer.parseInt(asistentes.getText().toString());
                        asis++;
                        asistentes.setText(asis + "");
                        Toast.makeText(this, "Apuntado", Toast.LENGTH_SHORT).show();
                        aux = true;

                    }

                } catch (JSONException e) {

                    e.printStackTrace();
                    Toast.makeText(this, "Lo sentimos intentelo más tarde", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    //envia el pk de la actividad y le devuelve los datos
    private void cargarActividad() {
        //Creamos el JSON que vamos a mandar al servidor
        JSONObject jsonConsulta = new JSONObject();
        try {
            jsonConsulta.put(Tags.ID, id+"");
            jsonConsulta.put(Tags.RESULTADO, "ok");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //Hacemos petición de la actividad
        jsonConsulta = JSONUtil.hacerPeticionServidor("java/get_actividad/", jsonConsulta);
//        Log.i("MOSTRANDO JSON", String.valueOf(jsonConsulta));
        try {
            String p = jsonConsulta.getString(Tags.RESULTADO);

            //En caso de que conecte con el servidor
            if (p.contains(Tags.OK)) {
//                Log.e("JSON ACTIVIDAD",p);
                actividad = new Actividad(jsonConsulta);
//                new Thread() {
//                    @Override
//                    public void run() {
//                        if (descargar) {
//                            fotoPerfil = DescargarImagen.descargarImagen(Tags.SERVIDOR + "static/media/" + user.getImagenURL());
//                        }
//                        Message msg = new Message();
//                        msg.what = PERFIL_CARGADO;
//                        puente.sendMessage(msg);
//                    }
//                }.start();
            }
            //resultado falla por otro error
            else if (p.contains(Tags.ERROR)) {
                String msg = jsonConsulta.getString(Tags.MENSAJE);
                Log.e("Fail", jsonConsulta.toString());
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void mostrarActividad(){
//        Toast.makeText(this, actividad.getTitulo(), Toast.LENGTH_SHORT).show();

        toolbar.setTitle(actividad.getTitulo());

        TextView fecha= (TextView) findViewById(R.id.tvFecha2);
        asistentes= (TextView) findViewById(R.id.tvVisitas);
        TextView hora= (TextView) findViewById(R.id.tvHora);
        TextView precio= (TextView) findViewById(R.id.tvPrecio);
        TextView lugar= (TextView) findViewById(R.id.tvLugar);
        TextView org= (TextView) findViewById(R.id.tvOrganizador);
        TextView desc= (TextView) findViewById(R.id.tvDescripcion);

        CollapsingToolbarLayout img = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);

        String horaM = actividad.getHora().substring(0, actividad.getHora().length()-3);

        Bitmap bmp = DescargarImagen.comprobarImagen(actividad.getIm_name()+"", "actividades", actividad.getPk());

        if (bmp != null) {

            Drawable d = new BitmapDrawable(getResources(), bmp);

//            Log.e("DRAWABLE",d.toString());
            img.setBackground(d);
        }

        fecha.setText(actividad.getFecha());
        asistentes.setText(actividad.getNumero_asistentes());
        hora.setText(horaM);
        precio.setText(actividad.getPrecio()+"€");
        lugar.setText(actividad.getLugar());
        org.setText(actividad.getOrganizador());
        desc.setText(actividad.getDescripcion());
    }

    private boolean checkUser(){
        if(Usuario.getToken(getApplicationContext()).length()>0){
//            Toast.makeText(this, "Iniciado Sesion", Toast.LENGTH_SHORT).show();
            return true;
        }else{
//            Toast.makeText(this, "No Iniciado Sesion", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        actividad = null;
        cargarActividad();
        mostrarActividad();

        if(Usuario.getToken(getApplicationContext()).length()>0) {
            t = Usuario.getToken(getApplicationContext()).substring(0, 1);
        }
        toolbar.setTitle(actividad.getTitulo());

        fab = (FloatingActionButton) findViewById(R.id.fab);

        if (t.equals("0")) {
            fab.setImageResource(R.drawable.ic_mode_edit_black_24dp);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent actividad = new Intent(getApplicationContext(), new EditActividad().getClass());
                    actividad.putExtra("id", id);
                    startActivity(actividad);
                }
            });
        } else {

            if(apuntado() || aux) {
                fab.setImageResource(R.drawable.ic_visibility_off_white_24dp);

            }else{
                fab.setImageResource(R.drawable.ic_remove_red_eye_white_24dp);
            }

            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (checkUser()) {
                        asistir();
                        //                        Toast.makeText(ActividadVista.this, "Bien", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent login = new Intent(getApplicationContext(), new Login().getClass());
                        startActivity(login);
                    }
                }
            });
        }

//        if(apuntado() || aux) {
//            fab.setImageResource(R.drawable.ic_visibility_off_white_24dp);
//
//        }else{
//            fab.setImageResource(R.drawable.ic_remove_red_eye_white_24dp);
//        }

    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void setActionBar(@Nullable android.widget.Toolbar toolbar) {
        super.setActionBar(toolbar);

        toolbar.setTitle(actividad.getTitulo());
    }
}
