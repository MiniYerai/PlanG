package es.plang.ruben.plang.BDInterna;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by Ruben on 04/06/2017.
 */

public class ContratoBD {

    //CONSTANTES PROVEEDOR GENERICO
//    public final static String AUTORIDAD = "es.plang.ruben.plang.";
//    public final static Uri CONTENT_URI = Uri.parse("content://"+AUTORIDAD);
//    public final static Uri CONTENT_URI_NOTA = Uri.withAppendedPath(CONTENT_URI, TablaNota.TABLA);
//    public final static Uri CONTENT_URI_LITA = Uri.withAppendedPath(CONTENT_URI, TablaLista.TABLA);

    public final static String BASEDATOS = "config.sqlite";

    // Valores para la columna ESTADO
    public static final int ESTADO_OK = 0;
    public static final int ESTADO_SYNC = 1;

    private ContratoBD(){}

    public static abstract class TablaConfig implements BaseColumns {
        //BaseColumns incluye de forma predeterminada el campo _id
        public static final String TABLA = "config";

        public static final String COLOR = "color";

        public static final String[] PROJECTION_ALL = {_ID, COLOR};
        public static final String SORT_ORDER_DEFAULT = _ID + " desc";

        //TIPOS MIME
        //CONCRETO
//        public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + "/vnd." + AUTORIDAD + "." + TABLA;
        //TODO
//        public static final String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + "/vnd." + AUTORIDAD + "." + TABLA;

    }
}
