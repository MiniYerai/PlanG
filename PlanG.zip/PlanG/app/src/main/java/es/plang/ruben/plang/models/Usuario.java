package es.plang.ruben.plang.models;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import es.plang.ruben.plang.PeticionBD.Tags;

/**
 * Created by Ruben on 08/04/2017.
 */

public class Usuario {
    public long pk;
    public String usuario;
    public String nombre;
    public String apellidos;
    public String correo;
    public String codigo_postal;
    public String localidad;
    public String fecha_nacimiento;
    public String fecha_nacimiento2;

    //MODIFICAR DATOS DE DJANGO

    public Usuario(JSONObject json) {

        try{
            setPk(json.getLong(Tags.PK));
        }catch(JSONException e){
            e.printStackTrace();
        }
        try{
            setUsuario(json.getString(Tags.USUARIO));
        }catch (JSONException e){
            e.printStackTrace();
        }
        try{
            setNombre(json.getString(Tags.NOMBRE));
        }catch (JSONException e){
            e.printStackTrace();
        }
        try{
            setApellidos(json.getString(Tags.APELLIDOS));
        }catch (JSONException e){
            e.printStackTrace();
        }
        try{
            setCorreo(json.getString(Tags.CORREO));
        }catch (JSONException e){
            e.printStackTrace();
        }
        try{
            setCodigo_postal(json.getString(Tags.CODIGO_POSTAL));
        }catch (JSONException e){
            e.printStackTrace();
        }
        try{
            setLocalidad(json.getString(Tags.LOCALIDAD));
        }catch (JSONException e){
            e.printStackTrace();
        }

        try{
            setFecha_nacimiento(json.getString(Tags.FECHA));
        }catch (JSONException e){
            e.printStackTrace();
        }
        try{
            setFecha_nacimiento2(json.getString(Tags.FECHA2));
        }catch (JSONException e){
            e.printStackTrace();
        }

    }

    //GETTERS TOKEN
    public static String getIDToken(String token){
        if(token!=null && !token.equals(""))
            return token.substring(0, token.indexOf("_"));
        else
            return -1+"";
    }
    public static String getID(Context context){
        String token = getToken(context);
        if(token!=null && !token.equals(""))
            return token.substring(1, token.indexOf("_"));
        else
            return -1+"";
    }
    public static String getToken(Context context){
//        Log.i("DEBUG","Accediendo a las preferencias");
        SharedPreferences pref = context.getSharedPreferences("preferencias", Activity.MODE_PRIVATE);
        String token=pref.getString("token", "");
        return token;
    }

    public static void guardarEnPref(Activity act, String usuario, String token){
        SharedPreferences pref = act.getSharedPreferences("preferencias", Activity.MODE_PRIVATE);
        SharedPreferences.Editor edit=pref.edit();
        edit.putString("usuario", usuario);
        edit.putString("token",token);
        edit.putBoolean("login1", false);
        edit.apply();
    }

    public static void cerrarSesion(Activity act){
        SharedPreferences pref = act.getSharedPreferences("preferencias", Activity.MODE_PRIVATE);
        SharedPreferences.Editor edit=pref.edit();
        edit.clear();
        edit.apply();
    }

    //GETTERS AND SETTERS


    public String getFecha_nacimiento2() {
        return fecha_nacimiento2;
    }

    public void setFecha_nacimiento2(String fecha_nacimiento2) {
        this.fecha_nacimiento2 = fecha_nacimiento2;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public long getPk() {
        return pk;
    }

    public void setPk(long pk) {
        this.pk = pk;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getCodigo_postal() {
        return codigo_postal;
    }

    public void setCodigo_postal(String codigo_postal) {
        this.codigo_postal = codigo_postal;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }
}
