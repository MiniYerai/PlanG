package es.plang.ruben.plang.models;

import org.json.JSONException;
import org.json.JSONObject;

import es.plang.ruben.plang.PeticionBD.Tags;

/**
 * Created by Ruben on 08/04/2017.
 */

public class Actividad {

    public long pk;
    public String titulo;
    public String fecha;
    public String hora;
    public String lugar;
    public String tipo_actividad;
    public String numero_asistentes;
    public String descripcion;
    public String precio;
    public String imagen;
    public String organizador;
    public boolean suspendido;
    public boolean lista_asistentes;
    public String im_name;

    //MODIFICAR DATOS DE DJANGO

    public Actividad(JSONObject json) {
        try {
            setPk(json.getLong(Tags.PK));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setTitulo(json.getString(Tags.TITULO));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setFecha(json.getString(Tags.FECHA));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setLista_asistentes(json.getBoolean(Tags.LISTA_ASISTENTES));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setHora(json.getString(Tags.HORA));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setLugar(json.getString(Tags.LUGAR));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setTipo_actividad(json.getString(Tags.TIPO_ACTIVIDAD));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setNumero_asistentes(json.getString(Tags.NUMERO_ASISTENTES));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setDescripcion(json.getString(Tags.DESCRIPCION));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setPrecio(json.getString(Tags.PRECIO));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {

            setImagen(json.getString(Tags.IMAGEN));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setOrganizador(json.getString(Tags.ORGANIZADOR));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setSuspendido(json.getBoolean(Tags.SUSPENSO));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setIm_name(json.getString(Tags.IM_NAME));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // GETTER AND SETTER

    public String getIm_name() {
        return im_name;
    }

    public void setIm_name(String im_name) {
        this.im_name = im_name;
    }

    public boolean isLista_asistentes() {
        return lista_asistentes;
    }

    public void setLista_asistentes(boolean lista_asistentes) {
        this.lista_asistentes = lista_asistentes;
    }

    public boolean isSuspendido() {
        return suspendido;
    }

    public void setSuspendido(boolean suspendido) {
        this.suspendido = suspendido;
    }

    public String getOrganizador() {
        return organizador;
    }

    public void setOrganizador(String organizador) {
        this.organizador = organizador;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getTipo_actividad() {
        return tipo_actividad;
    }

    public void setTipo_actividad(String tipo_actividad) {
        this.tipo_actividad = tipo_actividad;
    }

    public String getNumero_asistentes() {
        return numero_asistentes;
    }

    public void setNumero_asistentes(String numero_asistentes) {
        this.numero_asistentes = numero_asistentes;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public long getPk() {
        return pk;
    }

    public void setPk(long pk) {
        this.pk = pk;
    }
}
