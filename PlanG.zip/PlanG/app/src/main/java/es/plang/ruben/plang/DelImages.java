package es.plang.ruben.plang;

import android.os.Environment;
import android.util.Log;

import java.io.File;

/**
 * Created by dreams on 9/06/17.
 */

public class DelImages {

    public void folderImages(){

        File dir = new File(Environment.getExternalStorageDirectory()+"/planG/actividades");
        //comprueba si es directorio.
        if (dir.isDirectory())
        {
            //obtiene un listado de los archivos contenidos en el directorio.
            String[] hijos = dir.list();
            //Elimina los archivos contenidos.
            for (int i = 0; i < hijos.length; i++)
            {
                new File(dir, hijos[i]).delete();
            }
        }
    }
    public void imagesdel(long pk, String img){

        File dir = new File(Environment.getExternalStorageDirectory()+"/planG/actividades");
        //comprueba si es directorio.
        if (dir.isDirectory())
        {
            //obtiene un listado de los archivos contenidos en el directorio.
            String[] hijos = dir.list();
            //Elimina los archivos contenidos.
            for (int i = 0; i < hijos.length; i++)
            {
                String[] substr = hijos[i].split("_");


                if(substr.length>1) {
//                    Log.e("IMAGEN",hijos[i]+" -+- "+img);
                    long pk2 = Long.parseLong(substr[1]);
                    if(pk==pk2){
                        if(!hijos[i].equals(img)){
//                            Log.e("IMAGEN",hijos[i]+" -- "+img);
                            new File(dir, hijos[i]).delete();
                        }
                    }
//                    Log.e("IMAGEN", substr[1]);
                }
//                Log.e("IMAGEN",pk+"");
//                Log.e("IMAGEN",img);
            }
        }
    }
}
