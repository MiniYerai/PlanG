package es.plang.ruben.plang.models;

import org.json.JSONException;
import org.json.JSONObject;

import es.plang.ruben.plang.PeticionBD.Tags;

/**
 * Created by Ruben on 27/05/2017.
 */

public class Asistentes {

    public long pk;
    public String usuario;
    public String nombre_user;

    public Asistentes(JSONObject json) {

        try {
            setPk(json.getLong(Tags.PK));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setNombre_user(json.getString(Tags.NOMBRE));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try{
            setUsuario(json.getString(Tags.USUARIO));
        }catch (JSONException e){
            e.printStackTrace();
        }
    }

    // GETTERS AND SETTERS

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public long getPk() {
        return pk;
    }

    public void setPk(long pk) {
        this.pk = pk;
    }

    public String getNombre_user() {
        return nombre_user;
    }

    public void setNombre_user(String nombre_user) {
        this.nombre_user = nombre_user;
    }
}
