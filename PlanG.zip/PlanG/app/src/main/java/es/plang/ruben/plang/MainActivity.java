package es.plang.ruben.plang;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
//PUENTE
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Handler;

import java.lang.reflect.Array;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
//--------------------------------------------------
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import es.plang.ruben.plang.PeticionBD.JSONUtil;
import es.plang.ruben.plang.PeticionBD.Tags;
import es.plang.ruben.plang.models.Actividad;
import es.plang.ruben.plang.models.Tarea;
import es.plang.ruben.plang.models.Tipo;
import es.plang.ruben.plang.models.Usuario;
import es.plang.ruben.plang.utils.DescargarImagen;

public class MainActivity extends AppCompatActivity{ //implements AdaptadorActividad.OnItemClickListener, LoaderManager.LoaderCallbacks<Cursor> {

    private Actividad actividad;
    private ArrayList<Actividad> listadoActividades;
    String t = "1";

    ActividadesAdapter adapter;

    SwipeRefreshLayout reloadActividad;

    private ListView listaUI;
    private LinearLayoutManager linearLayoutManager;
    private CharSequence[] listtipos;
    ArrayList<Integer> PKtipos = new ArrayList<Integer>();

    //PUENTE PARA SINCRONIZAR
    private Handler puente;
    //THREADPOOL
    private  ThreadPoolExecutor pool = (ThreadPoolExecutor)Executors.newFixedThreadPool(1);
    ArrayList<Tarea> arrayTareas = new ArrayList<>();

    private static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 1 ;
    private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 2 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if(Usuario.getToken(getApplicationContext()).length()>0) {
            t = Usuario.getToken(getApplicationContext()).substring(0, 1);

        }

        permisos();

        // RECARGA LAS ACTIVIDADES
        reload();

        // crea un array vacio de Actividad
        //----------------------------------------------------
//        listadoActividades = new ArrayList<Actividad>();

        //PUENTE PARA CARGAR LAS IMAGENES

        if(t.equals("1")) {
            puente = new Handler() {
                @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                @Override
                public void handleMessage(Message msg) {
                    if (msg.what == 100) {

                        LinearLayout carta = (LinearLayout) msg.obj;
                        Bitmap bit = DescargarImagen.comprobarImagen(msg.arg1 + "", "actividades", -1);

                        Drawable d = new BitmapDrawable(getResources(), bit);

                        //Drawable d = new BitmapDrawable(getResources(), DescargarImagen.descargarImagen(Tags.SERVIDOR +Tags.MEDIA + actividad.getImagen()));


//                        Toast.makeText(MainActivity.this, d.toString().length()+"", Toast.LENGTH_SHORT).show();
//                        if(d.toString().length()!=49){
                            carta.setBackground(d);
//                        }else{
//                            carta.setBackgroundResource(R.drawable.default2);
//                        }
                        //                    ImageView b = (ImageView) msg.obj;
                        //                    Bitmap bmp = DescargarImagen.comprobarImagen(msg.arg1+"", "categorias");
                        //                    b.setImageBitmap(bmp);
                    }
                }
            };
        }
        //guarda los datos del servidor en el array de forma Asincrona con Asinctasck
        mostrar_actividades(false,listadoActividades);
        lista_tipos();
        //----------------------------------------------------

        //FILTRO
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createAlertFilter();
            }
        });

//         Preparar lista
//        listaUI = (RecyclerView) findViewById(R.id.lista);
//        listaUI.setHasFixedSize(true);
//
//        linearLayoutManager = new LinearLayoutManager(this);
//        listaUI.setLayoutManager(linearLayoutManager);
//
//        adaptador = new AdaptadorActividad(this, this);
//        listaUI.setAdapter(adaptador);
//
//         Iniciar loader
//        getSupportLoaderManager().restartLoader(1, null, this);

        //Deslizar item para borrarlo
//        deslizador();
    }

    private void permisos() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);

            }
        }
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);

            }
        }
    }

    private void reload(){
        reloadActividad = (SwipeRefreshLayout) findViewById(R.id.reloadActividad);
        reloadActividad.setColorSchemeResources(R.color.musical,R.color.deportiva,R.color.viaje,R.color.teatro);
        reloadActividad.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if(adapter != null) {
                            adapter.notifyDataSetChanged();
                        }
                        mostrar_actividades(false,listadoActividades);
                        lista_tipos();
                        reloadActividad.setRefreshing(false);
                    }
                }, 3000);
            }
        });
    }
    private void deslizador(){
        SwipeListViewTouchListener touchListener =new SwipeListViewTouchListener(listaUI,new SwipeListViewTouchListener.OnSwipeCallback() {
            @Override
            public void onSwipeLeft(ListView listView, int [] reverseSortedPositions) {
//                Aqui ponemos lo que hara el programa cuando deslizamos un item ha la izquierda
                listadoActividades.remove(reverseSortedPositions[0]);
                mostrar_actividades(false,listadoActividades);
                lista_tipos();
                adapter.notifyDataSetChanged();
//                listaUI.setAdapter(adapter);
            }

            @Override
            public void onSwipeRight(ListView listView, int [] reverseSortedPositions) {
                //Aqui ponemos lo que hara el programa cuando deslizamos un item ha la derecha
                listadoActividades.remove(reverseSortedPositions[0]);
                mostrar_actividades(false,listadoActividades);
                lista_tipos();
                adapter.notifyDataSetChanged();
//                listaUI.setAdapter(adapter);
            }
        },true, false);

        //Escuchadores del listView
        listaUI.setOnTouchListener(touchListener);
        listaUI.setOnScrollListener(touchListener.makeScrollListener());
    }

    //crea la alerta de filtros
    public void createAlertFilter(){

        // arraylist to keep the selected items
        final ArrayList seletedItems=new ArrayList();

        //Crea el alert dialog del filtro
        AlertDialog.Builder dialogo = new AlertDialog.Builder(this);
        dialogo.setTitle("Filtrar Actividades");
        dialogo.setMultiChoiceItems(listtipos, null, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int indexSelected, boolean isChecked) {
                if (isChecked) {
                    // If the user checked the item, add it to the selected items
                    seletedItems.add(indexSelected);
//                    Log.i("Filtrado",seletedItems.toString());
                } else if (seletedItems.contains(indexSelected)) {
                    // Else, if the item is already in the array, remove it
                    seletedItems.remove(Integer.valueOf(indexSelected));
                }
            }
        });

        dialogo.setCancelable(false);
        dialogo.setPositiveButton("Filtrar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo, int id) {

                aceptar(seletedItems);
            }
        });
        dialogo.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo, int id) {
                cancelar();
            }
        });
        dialogo.show();
    }

    //crea la alerta de suspender
    public void createAlertDel(String ti, final long pk, boolean sus){

        //Crea el alert dialog
        AlertDialog.Builder dialogo = new AlertDialog.Builder(this);
        dialogo.setTitle(ti);

        if (sus){
            dialogo.setMessage("¿Seguro que quiere quitar suspender esta actividad?");

            dialogo.setCancelable(false);
            dialogo.setPositiveButton("Quitar Suspenso", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo, int id) {

                    //json que devuelve
                    JSONObject respuesta = new JSONObject();
                    //json que envia
                    JSONObject enviar = new JSONObject();

                    //        Log.i("FILTRO 1",filtro.toString());

                    try {

                        if (t.equals("0")) {
                            enviar.put(Tags.RESULTADO, Tags.OK);
                            enviar.put(Tags.PK, pk);
                            enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
                            enviar.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));

                        }

                        //recibe respuesta
                        respuesta = JSONUtil.hacerPeticionServidor("java/suspender_actividad/", enviar);

                        //comprueba de que se realizo con exito
                        if (respuesta.getString(Tags.RESULTADO).contains("ok")) {
                            Toast.makeText(MainActivity.this, "Se ha quipado la Suspension de la actividad", Toast.LENGTH_SHORT).show();
                            mostrar_actividades(false,listadoActividades);
                            lista_tipos();
                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }else {
            dialogo.setMessage("¿Seguro que quiere suspender esta actividad?");

            dialogo.setCancelable(false);
            dialogo.setPositiveButton("Suspender", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo, int id) {

                    //json que devuelve
                    JSONObject respuesta = new JSONObject();
                    //json que envia
                    JSONObject enviar = new JSONObject();

                    //        Log.i("FILTRO 1",filtro.toString());

                    try {

                        if (t.equals("0")) {
                            enviar.put(Tags.RESULTADO, Tags.OK);
                            enviar.put(Tags.PK, pk);
                            enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
                            enviar.put(Tags.USUARIO_ID, Usuario.getID(getApplicationContext()));

                        }

                        //recibe respuesta
                        respuesta = JSONUtil.hacerPeticionServidor("java/suspender_actividad/", enviar);

                        //comprueba de que se realizo con exito
                        if (respuesta.getString(Tags.RESULTADO).contains("ok")) {
                            Toast.makeText(MainActivity.this, "Se ha Suspendido la actividad", Toast.LENGTH_SHORT).show();
                            mostrar_actividades(false,listadoActividades);
                            lista_tipos();
                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
        dialogo.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo, int id) {
                cancelar();
            }
        });
        dialogo.show();
    }

    // Filtra las actividades
    public void aceptar(ArrayList lista) {

        adapter.notifyDataSetChanged();
        if(lista.size()>0) {
            mostrar_actividades(true, lista);
        }
//        for (Object a: lista) {
//            Log.i("Number", (String) tipos[a.hashCode()]);
//        }
//        Toast t=Toast.makeText(this,"Filtrado: "+lista, Toast.LENGTH_SHORT);
//        t.show();
    }
//
    public void cancelar() {
        //finish();
    }

    //----------------------------------------------------------------------------------------------

    //muestra las actividades mas recientes desde hoy en adelante
    public void mostrar_actividades(Boolean filtro, ArrayList lista){
        //json que devuelve
        JSONObject respuesta = new JSONObject();
        //json que envia
        JSONObject enviar = new JSONObject();

//        Log.i("FILTRO 1",filtro.toString());

        try {

            //Hace peticion al servidor
            if(filtro) {
                enviar.put(Tags.RESULTADO, Tags.OK);
                enviar.put(Tags.FILTRO, Tags.OK);

                ArrayList<Integer> filtros = new ArrayList<Integer>();

                for(int i=0;i<lista.size();i++){
//                    Log.e("1", (String) listtipos[0]);
                    filtros.add(PKtipos.get((int) lista.get(i)));
//                    Log.e("Listasssss",lista.get(i).toString());
                }
                enviar.put(Tags.TIPO, filtros);
            }else {
                enviar.put(Tags.RESULTADO, Tags.OK);
                enviar.put(Tags.FILTRO, Tags.NOT);
            }

            if (t.equals("0")){
                enviar.put(Tags.USUARIO_ID,Usuario.getID(getApplicationContext()));
                enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
                enviar.put(Tags.STAFF,"YES");
            }else{
                enviar.put(Tags.STAFF,"NO");
            }

//            Log.i("Entra",lista.toString());
            //recibe respuesta
            respuesta = JSONUtil.hacerPeticionServidor("java/actividades/", enviar);
//            Log.i("FILTRO 2",filtro.toString());
//            Log.i("RESPUESTA",respuesta.toString());
//            Log.i("Entra",respuesta.toString());

            //comprueba de que se realizo con exito
            if (respuesta.getString(Tags.RESULTADO).contains("ok")) {

                JSONArray arrayActividad = respuesta.getJSONArray("actividades");
                Actividad temp;

                if (arrayActividad != null) {
                    listadoActividades = new ArrayList<Actividad>();
                    for (int i = 0; i < arrayActividad.length(); i++) {

                        //Log.i("Actividades", arrayActividad.getJSONObject(i).toString());
                        temp = new Actividad(arrayActividad.getJSONObject(i));
//                        Log.i("Actividad", temp.getImagen());

                        listadoActividades.add(temp);
                    }
                }
                crearLista();
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //Se descarga la lista de tipos
    public void lista_tipos(){
        //json que devuelve
        JSONObject respuesta = new JSONObject();
        //json que envia
        JSONObject enviar = new JSONObject();

        try {
            //Hace peticion al servidor
            enviar.put(Tags.RESULTADO,Tags.OK);

            if (t.equals("0")){
                enviar.put(Tags.TOKEN, Usuario.getToken(getApplicationContext()));
                enviar.put(Tags.USUARIO_ID,Usuario.getID(getApplicationContext()));
                enviar.put(Tags.STAFF,"YES");
            }else{
                enviar.put(Tags.STAFF,"NO");
            }
            //recibe respuesta
            respuesta = JSONUtil.hacerPeticionServidor("java/tipos/", enviar);

            //comprueba de que se realizo con exito
            if(respuesta.getString(Tags.RESULTADO).contains("ok")){

                JSONArray arrayTipos = respuesta.getJSONArray("tipos");
                Tipo temp;

                if (arrayTipos != null) {
                    listtipos = new CharSequence[arrayTipos.length()];
                    int aux = 0;

                    for (int i = 0; i < arrayTipos.length(); i++) {

//                        //Log.i("TIPOS",arrayTipos.getJSONObject(i).toString());
                        temp = new Tipo(arrayTipos.getJSONObject(i));

//                        //Log.i("TIPO",temp.getNombre());
//                        aux=(int) temp.getPk();
//
//                        aux--;
//                        Log.e("TIPOS",aux+" "+temp.getNombre());
                        listtipos[i]=temp.getNombre();
                        PKtipos.add((int)temp.getPk());
                    }
                }
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //Crea la lista de 0
    public void crearLista(){

        adapter = new ActividadesAdapter();

        listaUI = (ListView) findViewById(R.id.lista);

        listaUI.setAdapter(adapter);

        if(adapter != null) {
            adapter.notifyDataSetChanged();
        }

        listaUI.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                if (t.equals("0")){
                    //Get the current alert object
                    String ti = listadoActividades.get(position).getTitulo();
                    long pka = listadoActividades.get(position).getPk();
                    boolean sus = listadoActividades.get(position).isSuspendido();
                    createAlertDel(ti, pka, sus);
                    return true;
                }else {
                    return false;
                }
            }
        });
//        Toast.makeText(this, listaUI.getOnItemLongClickListener().toString(), Toast.LENGTH_SHORT).show();
        listaUI.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int posicion, long id) {

                Intent actividad = new Intent(getApplicationContext(), new ActividadVista().getClass());
                actividad.putExtra("id", listadoActividades.get(posicion).getPk()+"");
                startActivity(actividad);
            }
        });
    }

//    public void onClick(AdaptadorActividad.ViewHolder holder, String id) {
//        Snackbar.make(findViewById(android.R.id.content), ":id = " + id,
//                Snackbar.LENGTH_LONG).show();
//    }

    public void descargarFoto(Actividad a){
        if(a.getImagen().length()>0 && a.getImagen()!="nada") {
            Bitmap bmp = DescargarImagen.descargarImagen(Tags.SERVIDOR +Tags.MEDIA + a.getImagen());
            DescargarImagen.guardaImagen(bmp, a.getIm_name() + "", "actividades");
        }
        else{
            Bitmap bmp = BitmapFactory.decodeResource(getResources(),R.drawable.default2);
        }
    }
    public void hacerTarea(){
        pool.execute(new Thread(){
            @Override
            public void run(){
                while (arrayTareas.size() > 0){

                    if (arrayTareas.get(0).getFuncion().contains("descargarFoto")) {
                        descargarFoto((Actividad) arrayTareas.get(0).getDato());
                        Message msg = new Message();
                        msg.what = 100;
                        msg.arg1 = Integer.parseInt(((Actividad) arrayTareas.get(0).getDato()).getPk() + "");
                        msg.obj = arrayTareas.get(0).getDato2();

                        puente.sendMessage(msg);


                    }
                    arrayTareas.remove(0);

                }
            }
        });
    }

    //----------------------------------------------------------------------------------------------

    // muenu del action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(t.equals("0")) {
            getMenuInflater().inflate(R.menu.menu, menu);
        }else{
            getMenuInflater().inflate(R.menu.menu_user, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.action_log:
                if(Usuario.getToken(getApplicationContext()).length()>0){
                    Intent p = new Intent(getApplicationContext(), new Perfil().getClass());
                    startActivity(p);
                }else {
                    Intent login = new Intent(getApplicationContext(), new Login().getClass());
                    startActivity(login);
                }
                return true;
            case R.id.action_reload:
                adapter.notifyDataSetChanged();
                mostrar_actividades(false,listadoActividades);
                lista_tipos();
                return true;
            case R.id.action_settings:
//                Intent s = new Intent(getApplicationContext(), new ActivityConfiguracion().getClass());
//                startActivity(s);
                Toast.makeText(this, "Proximamente estara", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_add:

                Intent add = new Intent(getApplicationContext(), new EditActividad().getClass());
                startActivity(add);

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if(Usuario.getToken(getApplicationContext()).length()>0) {
//            Log.e("ENTRA","**************************************");
            t = Usuario.getToken(getApplicationContext()).substring(0, 1);
        }else{
            t="1";
        }

        if(t.equals("1")) {
            puente = new Handler() {
                @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                @Override
                public void handleMessage(Message msg) {
                    if (msg.what == 100) {
                        LinearLayout carta = (LinearLayout) msg.obj;
                        Bitmap bit = DescargarImagen.comprobarImagen(msg.arg1 + "", "actividades",-1);

                        Drawable d = new BitmapDrawable(getResources(), bit);

                        //Drawable d = new BitmapDrawable(getResources(), DescargarImagen.descargarImagen(Tags.SERVIDOR +Tags.MEDIA + actividad.getImagen()));


//                        Toast.makeText(MainActivity.this, d.toString().length()+"", Toast.LENGTH_SHORT).show();
//                        if(d.toString().length()!=49){
                        carta.setBackground(d);
//                        }else{
//                            carta.setBackgroundResource(R.drawable.default2);
//                        }
                        //                    ImageView b = (ImageView) msg.obj;
                        //                    Bitmap bmp = DescargarImagen.comprobarImagen(msg.arg1+"", "categorias");
                        //                    b.setImageBitmap(bmp);
                    }
                }
            };
        }
        //guarda los datos del servidor en el array de forma Asincrona con Asinctasck
        mostrar_actividades(false,listadoActividades);
        lista_tipos();
    }

    //adaptador de la actividad
    public class ActividadesAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            int count=listadoActividades.size(); //counts the total number of elements from the arrayList
            return count;//returns the total count to adapter
        }

        // CONVIERTO LA POSICION EN EL PK
        public Actividad getItem(int position) {
            return listadoActividades.get(position);
        }
        public long getItemId(int position) {
            //Log.e("PK",listcategoria.get(position).getPk()+"");
            return listadoActividades.get(position).getPk();
        }


        //crea las card views
        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
        @NonNull
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            //Get the current alert object
            final Actividad actividad = getItem(position);

            final ViewHolder holder;

//                Log.e("ERROR NULL", actividad.getTitulo());
            if (t.equals("1")) {

                //Inflate the view
                if (convertView == null) {
                    convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista_actividad, parent, false);

                    holder = new ViewHolder();

                    holder.titulo = (TextView) convertView.findViewById(R.id.nombre);
                    holder.fecha = (TextView) convertView.findViewById(R.id.fecha);
                    holder.carta = (LinearLayout) convertView.findViewById(R.id.carta);
                    holder.img = (ImageView) convertView.findViewById(R.id.ivType);
                    holder.tvSus = (TextView) convertView.findViewById(R.id.tvSuspenso);

                    convertView.setTag(holder);
                    //            TextView dia = (TextView) convertView.findViewById(R.id.tvDiaGrupo);
                    //            TextView descripcion = (TextView) convertView.findViewById(R.id.tvDescripcionGrupo);
                    //            TextView hora = (TextView) convertView.findViewById(R.id.tvHoraGrupo);
                    //            TextView plazas = (TextView) convertView.findViewById(R.id.tvplazas);

                    //Log.i("Descripcion: ",grupo.getDescripcion());

                } else {
//                    Log.e("ERROR NOT NULL", actividad.getTitulo());
                    holder = (ViewHolder) convertView.getTag();
                }

                Bitmap bmp = DescargarImagen.comprobarImagen(actividad.getIm_name() + "", "actividades", actividad.getPk());

                if (bmp != null) {
                    Drawable d = new BitmapDrawable(parent.getResources(), bmp);

                    holder.carta.setBackground(d);
                } else {
                    holder.carta.setBackgroundResource(R.drawable.default2);
                    arrayTareas.add(new Tarea("descargarFoto", actividad, holder.carta));
                    hacerTarea();
                }

//                holder.carta.setBackgroundResource(R.drawable.default2);


//                Log.e("ERROR DATOS", actividad.getTitulo());

                holder.titulo.setText(actividad.getTitulo());
                holder.fecha.setText(actividad.getFecha());

//                Log.e("SUS",actividad.isSuspendido()+"");
                if(actividad.isSuspendido()){
                    holder.tvSus.setVisibility(View.VISIBLE);
                }else{
                    holder.tvSus.setVisibility(View.INVISIBLE);
                }

                //Log.i("Tipo",actividad.getTipo_actividad());
                switch (actividad.getTipo_actividad()) {

                    case "actividad":
                        holder.img.setImageResource(R.mipmap.actividad);
                        //Log.i("Tipo","ACTIVIDAD");
                        break;
                    case "musical":
                        holder.img.setImageResource(R.mipmap.music);
                        //Log.i("Tipo","MUSICA");
                        break;
                    case "deportiva":
                        holder.img.setImageResource(R.mipmap.sport);
                        //Log.i("Tipo","DEPORTIVA");
                        break;
                    case "viaje":
                        holder.img.setImageResource(R.mipmap.travel);
                        //Log.i("Tipo","VIAJE");
                        break;
                    case "salon friki":
                        //img.setImageResource(R.drawable.friki);
                        holder.img.setImageResource(R.mipmap.friki);
                        //Log.i("Tipo","FRIKI");
                        break;
                    case "teatro":
                        holder.img.setImageResource(R.mipmap.teatro);
                        //Log.i("Tipo","TEATRO");
                        break;
                    case "gastronomia":
                        holder.img.setImageResource(R.mipmap.gastronomia);
                        //Log.i("Tipo","GASTRONOMIA");
                        break;
                    default:
                        holder.img.setImageResource(R.mipmap.actividad);
                        //Log.i("Tipo","POR DEFECTO");
                }
            }else if(t.equals("0")){

//                Log.e("eres","ADMINISTRADOR");
                //Inflate the view

//                Log.e("ERROR DATOS", "ENTRA");
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista_org, parent, false);

                TextView titulo = (TextView) convertView.findViewById(R.id.nombre);
                ImageView img = (ImageView) convertView.findViewById(R.id.ivType);
                TextView fecha = (TextView) convertView.findViewById(R.id.fecha);
                LinearLayout llActive = (LinearLayout) convertView.findViewById(R.id.llActive);

                if(actividad.isSuspendido()){
                    llActive.setBackgroundResource(R.color.suspenso);
                    titulo.setTextColor(Color.WHITE);
                    fecha.setTextColor(Color.WHITE);
                }

//                Log.e("ERROR DATOS", actividad.getTitulo());
                String ti = "";
                if(actividad.getTitulo().length()>35){
                    ti=actividad.getTitulo().substring(0,35)+"...";
                }else{
                    ti = actividad.getTitulo();
                }
                titulo.setText(ti);
                fecha.setText(actividad.getFecha());

                //Log.i("Tipo",actividad.getTipo_actividad());
                switch (actividad.getTipo_actividad()) {

                    case "actividad":
                        img.setImageResource(R.mipmap.actividad);
                        //Log.i("Tipo","ACTIVIDAD");
                        break;
                    case "musical":
                        img.setImageResource(R.mipmap.music);
                        //Log.i("Tipo","MUSICA");
                        break;
                    case "deportiva":
                        img.setImageResource(R.mipmap.sport);
                        //Log.i("Tipo","DEPORTIVA");
                        break;
                    case "viaje":
                        img.setImageResource(R.mipmap.travel);
                        //Log.i("Tipo","VIAJE");
                        break;
                    case "salon friki":
                        //img.setImageResource(R.drawable.friki);
                        img.setImageResource(R.mipmap.friki);
                        //Log.i("Tipo","FRIKI");
                        break;
                    case "teatro":
                        img.setImageResource(R.mipmap.teatro);
                        //Log.i("Tipo","TEATRO");
                        break;
                    case "gastronomia":
                        img.setImageResource(R.mipmap.gastronomia);
                        //Log.i("Tipo","GASTRONOMIA");
                        break;
                    default:
                        img.setImageResource(R.mipmap.actividad);
                        //Log.i("Tipo","POR DEFECTO");
                }
                img.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MainActivity m = new MainActivity();
                        m.createAlertFilter();
                    }
                });
            }



//            if(actividad.getImagen().length()>0){
//                Log.i("Tiene imagen",actividad.getTitulo());
//            }else{
//                Log.i("No tiene imagen",actividad.getTitulo());
//            }

//            dia.setText(grupo.getDia_semana());
//            hora.setText(grupo.getHora_inicio());
//            plazas.setText(grupo.getPlazas_ocupadas()+"/"+grupo.getLimite_plazas());

//            final String name=actividad.getTitulo();
//            Log.v("Añadido",name);
//            Button apuntar = (Button) convertView.findViewById(R.id.btApuntarse);
//            TextView tvApuntarse = (TextView) convertView.findViewById(R.id.tvApuntado);

//            if(grupo.getApuntado()>0){
//                apuntar.setVisibility(View.GONE);
//                tvApuntarse.setVisibility(View.VISIBLE);
//            }

//            apuntar.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    Log.i("Apuntado al grupo",name);
//
//                    JSONObject apuntado = new JSONObject();
//                    JSONObject respuesta = new JSONObject();
//                    try {
//                        apuntado.put(Tags.USUARIO_ID,
//                                Usuario.getID(getApplicationContext()));
//                        apuntado.put(Tags.TOKEN,Usuario.getToken(getApplicationContext()));
//                        apuntado.put(Tags.PK_SESION, grupo.getPk());
//                        apuntado.put(Tags.DIA_SESION, grupo.getDia_semana());
//
//
//                        apuntado = JSONUtil.hacerPeticionServidor(
//                                "usuarios/java/apuntarse_grupo/", apuntado);
//
//                        if(apuntado.getString(Tags.RESULTADO).contains("ok")){
//                            Log.i("Mensaje",apuntado.getString(Tags.MENSAJE));
//                        }
//
//                        adapter.clear();
//                        mostrar_clases_libres();
//
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//                }
//            });

            return convertView;
        }

    }
    private class ViewHolder {

        private TextView titulo;
        private TextView fecha;
        private LinearLayout carta;
        private ImageView img;
        private TextView tvSus;
    }
}