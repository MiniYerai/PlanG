package es.plang.ruben.plang.models;

import org.json.JSONException;
import org.json.JSONObject;

import es.plang.ruben.plang.PeticionBD.Tags;

/**
 * Created by Ruben on 17/04/2017.
 */

public class Tipo {

    public long pk;
    public String nombre;

    public Tipo(JSONObject json) {
        try {
            setPk(json.getLong(Tags.PK));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            setNombre(json.getString(Tags.NOMBRE));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //getter and setter
    public long getPk() {
        return pk;
    }

    public void setPk(long pk) {
        this.pk = pk;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
