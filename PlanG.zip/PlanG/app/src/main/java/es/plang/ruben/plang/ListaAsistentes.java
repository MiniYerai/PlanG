package es.plang.ruben.plang;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.menu.MenuView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import es.plang.ruben.plang.PeticionBD.JSONUtil;
import es.plang.ruben.plang.PeticionBD.Tags;
import es.plang.ruben.plang.models.Asistentes;
import es.plang.ruben.plang.models.Usuario;

public class ListaAsistentes extends AppCompatActivity {

    String t = "1";
    String pk;

    private Asistentes asistentes;
    private ArrayList<Asistentes> listadoAsistentes;

    public AsistentesAdapter2 adapter;

    SwipeRefreshLayout reloadAsistentes;

    private ListView listaA;
    private LinearLayoutManager linearLayoutManager;
    private boolean asistencia=false;

    Toolbar toolbar;

    String titulo ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_asistentes);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //boton de atras
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        //boton de atras
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        pk = getIntent().getStringExtra("id");

        if(Usuario.getToken(getApplicationContext()).length()>0) {
            t = Usuario.getToken(getApplicationContext()).substring(0, 1);
        }

        if(!t.equals("0")){
            Intent main = new Intent(getApplicationContext(),new MainActivity().getClass());
            startActivity(main);
        }

        // RECARGA LAS ACTIVIDADES
        reloadAsistentes = (SwipeRefreshLayout) findViewById(R.id.reloadActividad);
        reloadAsistentes.setColorSchemeResources(R.color.musical,R.color.deportiva,R.color.viaje,R.color.teatro);
        reloadAsistentes.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if(adapter != null) {
                            adapter.notifyDataSetChanged();
                        }
                        mostrar_asistentes();

                        reloadAsistentes.setRefreshing(false);
                    }
                }, 3000);
            }
        });
        //guarda los datos del servidor en el array de forma Asincrona
        mostrar_asistentes();
//        Toast.makeText(this, pk, Toast.LENGTH_SHORT).show();
        listaA.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Dialog dialogo = new Dialog(getApplicationContext());
                dialogo.setTitle("¿Seguro que esta ?");

            }
        });
    }

    //muestra las actividades mas recientes desde hoy en adelante
    public void mostrar_asistentes(){

        toolbar.setTitle("Sin Asistir");
        asistencia = false;
        //json que devuelve
        JSONObject respuesta = new JSONObject();
        //json que envia
        JSONObject enviar = new JSONObject();

//        Log.i("FILTRO 1",filtro.toString());

        try {

            //Hace peticion al servidor
            enviar.put(Tags.RESULTADO, Tags.OK);

            enviar.put(Tags.USUARIO_ID,Usuario.getID(getApplicationContext()));
            enviar.put(Tags.TOKEN,Usuario.getToken(getApplicationContext()));
            enviar.put(Tags.ASISTIDOS,asistencia);
            enviar.put(Tags.PK_ACTIVIDAD,pk);

            //recibe respuesta
            respuesta = JSONUtil.hacerPeticionServidor("java/asistentes/", enviar);

//            Log.i("RESPUESTA",respuesta.toString());
//            Log.i("Entra",respuesta.toString());

            //comprueba de que se realizo con exito
            if (respuesta.getString(Tags.RESULTADO).contains("ok")) {

//                Log.e("ASISTENTES", respuesta.toString());

                titulo = respuesta.getString("titulo");

                JSONArray arrayAsistentes = respuesta.getJSONArray("asistentes");
                Asistentes temp;

                if (arrayAsistentes != null) {
                    listadoAsistentes = new ArrayList<Asistentes>();
                    for (int i = 0; i < arrayAsistentes.length(); i++) {

                        //Log.i("Actividades", arrayActividad.getJSONObject(i).toString());
                        temp = new Asistentes(arrayAsistentes.getJSONObject(i));
//                        Log.i("Actividad", temp.getImagen());

                        listadoAsistentes.add(temp);
                    }
                }
                crearLista();
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //muestra las actividades mas recientes desde hoy en adelante
    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    public void mostrar_asistidos(){

        toolbar.setTitle("Asistidos");

        asistencia = true;

        //json que devuelve
        JSONObject respuesta = new JSONObject();
        //json que envia
        JSONObject enviar = new JSONObject();

//        Log.i("FILTRO 1",filtro.toString());

        try {

            //Hace peticion al servidor
            enviar.put(Tags.RESULTADO, Tags.OK);

            enviar.put(Tags.USUARIO_ID,Usuario.getID(getApplicationContext()));
            enviar.put(Tags.TOKEN,Usuario.getToken(getApplicationContext()));

            enviar.put(Tags.PK_ACTIVIDAD,pk);
            enviar.put(Tags.ASISTIDOS,asistencia);

            //recibe respuesta
            respuesta = JSONUtil.hacerPeticionServidor("java/asistentes/", enviar);

//            Log.i("RESPUESTA",respuesta.toString());
//            Log.i("Entra",respuesta.toString());

            //comprueba de que se realizo con exito
            if (respuesta.getString(Tags.RESULTADO).contains("ok")) {

//                Log.e("ASISTENTES", respuesta.toString());

                titulo = respuesta.getString("titulo");

                JSONArray arrayAsistentes = respuesta.getJSONArray("asistentes");
                Asistentes temp;

                listadoAsistentes = new ArrayList<Asistentes>();
                for (int i = 0; i < arrayAsistentes.length(); i++) {

                    //Log.i("Actividades", arrayActividad.getJSONObject(i).toString());
                    temp = new Asistentes(arrayAsistentes.getJSONObject(i));
//                        Log.i("Actividad", temp.getImagen());

                    listadoAsistentes.add(temp);
                }

                crearLista();
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //Crea la lista de 0
    public void crearLista(){

        TextView tvtitulo = (TextView) findViewById(R.id.tvTitulo);
        tvtitulo.setText(titulo);

        adapter = new AsistentesAdapter2();

        listaA = (ListView) findViewById(R.id.lista);

        listaA.setAdapter(adapter);

        if(adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    // muenu del action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu3, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.action_asistidos:
                if(asistencia){
                    mostrar_asistentes();
                }else {
                    mostrar_asistidos();
                }
                invalidateOptionsMenu();
                return true;
            case R.id.action_settings:
                Toast.makeText(this, "Proximamente estara", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_add:

                Intent add = new Intent(getApplicationContext(), new EditActividad().getClass());
                startActivity(add);

                return true;
            case R.id.action_edit:

//                Toast.makeText(this, pk, Toast.LENGTH_SHORT).show();
                Intent edit = new Intent(getApplicationContext(), new EditActividad().getClass());
                edit.putExtra("id", pk);
                startActivity(edit);

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (asistencia) {
            //in production you'd probably be better off keeping a reference to the item
            menu.findItem(R.id.action_asistidos)
                    .setIcon(R.drawable.ic_group_add_black_24dp)
                    .setTitle(R.string.strAsistidos);
        } else {
            menu.findItem(R.id.action_asistidos)
                    .setIcon(R.drawable.ic_group_black_24dp)
                    .setTitle(R.string.strAsistidos);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    protected void onResume() {
        super.onResume();

        toolbar = (Toolbar) findViewById(R.id.toolbar);
    }

    //le manda el pk del asistente para checkear la asistencia
    public void enviar(long pk, String nom){
        //json que devuelve
        JSONObject respuesta = new JSONObject();
        //json que envia
        JSONObject enviar = new JSONObject();

        try {

            //Hace peticion al servidor
            enviar.put(Tags.RESULTADO, Tags.OK);

            enviar.put(Tags.USUARIO_ID,Usuario.getID(getApplicationContext()));
            enviar.put(Tags.TOKEN,Usuario.getToken(getApplicationContext()));
            enviar.put(Tags.ASISTIDOS,asistencia);
            enviar.put(Tags.PK,pk);

            //recibe respuesta
            respuesta = JSONUtil.hacerPeticionServidor("java/ok_asistente/", enviar);

            //comprueba de que se realizo con exito
            if (respuesta.getString(Tags.RESULTADO).contains("ok")) {

                if(asistencia){
                    Toast.makeText(this, "Desapuntado " + nom, Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(this, "Apuntado " + nom, Toast.LENGTH_SHORT).show();
                }
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void updateLista(){

        adapter.notifyDataSetChanged();

        adapter = new AsistentesAdapter2();

        listaA = (ListView) findViewById(R.id.lista);

        listaA.setAdapter(adapter);

        if(adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    //adaptador de la actividad
    private class AsistentesAdapter2 extends BaseAdapter {

        @Override
        public int getCount() {
            int count=listadoAsistentes.size(); //counts the total number of elements from the arrayList
            return count;//returns the total count to adapter
        }

        // CONVIERTO LA POSICION EN EL PK
        public Asistentes getItem(int position) {
            return listadoAsistentes.get(position);
        }
        public long getItemId(int position) {
            //Log.e("PK",listcategoria.get(position).getPk()+"");
            return listadoAsistentes.get(position).getPk();
        }


        //crea las card views
        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
        @NonNull
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            //Get the current alert object
            final Asistentes asistente = getItem(position);

            final ViewHolder holder;

//                Log.e("ERROR NULL", actividad.getTitulo());
            //Inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista_asistentes, parent, false);

                holder = new ViewHolder();

                holder.nombre = (TextView) convertView.findViewById(R.id.nombre);
                holder.cb = (CheckBox) convertView.findViewById(R.id.cb);

                holder.nombre.setText(asistente.getNombre_user());

                holder.cb.setId((int) asistente.getPk());
                holder.cb.setText(asistente.getUsuario());

                final View finalConvertView = convertView;
                holder.cb.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        long pk =listadoAsistentes.get(position).getPk();
                        String no =listadoAsistentes.get(position).getNombre_user();

                        listadoAsistentes.remove(position);
                        notifyDataSetChanged();
                        updateLista();
                        enviar(pk, no);
//                        Toast.makeText(ListaAsistentes.this, holder.cb.getId()+"", Toast.LENGTH_SHORT).show();
                    }
                });

                convertView.setTag(holder);

                //Log.i("Descripcion: ",grupo.getDescripcion());

            } else {
//                    Log.e("ERROR NOT NULL", actividad.getTitulo());
                holder = (ViewHolder) convertView.getTag();
            }

            return convertView;
        }

    }
    private class ViewHolder {
        TextView nombre;
        CheckBox cb;
    }
}
