package es.plang.ruben.plang.PeticionBD;

/**
 * Created by Ruben on 08/04/2017.
 */

public class Tags {
    public static final String SERVIDOR = "https://plan-g2-kiwiadmin.c9users.io/"; //LA IP DEL SERVIDOR

    public static final String
        USUARIO = "usuario",
        NOMBRE = "nombre",
        APELLIDOS = "apellidos",
        CORREO = "correo",
        FECHA_NACIMIENTO = "fecha_nacimiento",
        CODIGO_POSTAL ="codigo_postal",
        LOCALIDAD = "localidad",
        PK = "pk",
        PK_USER = "pk_user",
        PK_ACTIVIDAD = "pk_actividad",
        TITULO = "titulo",
        FECHA = "fecha",
        FECHA2 = "fecha2",
        HORA = "hora",
        LUGAR ="lugar",
        TIPO_ACTIVIDAD = "tipo_actividad",
        NUMERO_ASISTENTES = "numero_asistentes",
        DESCRIPCION = "descripcion",
        PRECIO = "precio",
        IMAGEN = "imagen",
        TOKEN = "token",
        RESULTADO = "result",
        MENSAJE = "message",
        USUARIOLOGUEADO = "Usuario logueado",
        OK = "ok",
        ERROR = "error",
        MEDIA = "static/media/",
        FILTRO= "filtro",
        TIPO = "tipo",
        TIPO2 = "tipo2",
        NOT = "not",
        PASSWORD = "password",
        ID = "id",
        ORGANIZADOR = "organizador",
        STAFF = "staff",
        SUSPENSO = "suspenso",
        SESION = "sesion",
        ASISTIDOS = "asistidos",
        LISTA_ASISTENTES = "lista_asistentes",
        IM_NAME = "im_name",
        USUARIO_ID = "usuario_id";

//    https://plan-g2-kiwiadmin.c9users.io/media/imagenes/actividades/actividad_default.jpg
}
