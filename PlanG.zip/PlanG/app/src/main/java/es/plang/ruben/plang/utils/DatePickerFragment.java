package es.plang.ruben.plang.utils;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.widget.DatePicker;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import es.plang.ruben.plang.R;


/**
 * Created by jahid on 12/10/15.
 */
public class DatePickerFragment extends DialogFragment
         implements DatePickerDialog.OnDateSetListener {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    public void onDateSet(DatePicker view, int year, int month, int day) {
        // Do something with the date chosen by the user
        TextView tv1= (TextView) getActivity().findViewById(R.id.tvFecha);
        int mes = view.getMonth();
        mes++;
        String mes2 = mes+"";
        if(mes<10){
            mes2 = "0"+mes;
        }
        Date dt = new Date();

        SimpleDateFormat df = new SimpleDateFormat("yyyy");

        String formatteDate = df.format(dt);
//        Log.e("AÑO ACTUAL",formatteDate);
        tv1.setText(view.getDayOfMonth() + "/"+mes2+"/"+view.getYear());

    }
}